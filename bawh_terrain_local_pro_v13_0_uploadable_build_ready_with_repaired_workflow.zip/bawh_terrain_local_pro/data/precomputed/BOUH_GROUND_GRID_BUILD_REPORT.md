# BOUH Ground Grid Build Report — v12.9 Installable Android Release

## Current ground grid status

```text
ground_cells = 4303
analysis_type = partial ready analyzed ground grid from Landsat/DEM
truth_status = partial_raw_grid_landsat_dem_not_full_spectral
```

## Source basis

The integrated ground grid is the v12.6 final ready analyzed ground grid.

Sources represented in the analyzed SQLite cells:

```text
Landsat reflectance composite
Landsat TIR
Landsat QA_PIXEL
DEM n19_e036_3arc_v2
```

## Top verified cell

```text
cell_id = partial_raw_0004117
lat = 19.41022162800518
lng = 36.86820999932388
final_ground_score = 66.0
class = Class C
truth_status = partial_raw_grid_landsat_dem_not_full_spectral
```

## Not claimed / not available

```text
true Sentinel NDVI = not available
true Sentinel NDWI = not available
true Sentinel BSI = not available
true Sentinel NDMI = not available
true SWIR full-stack = not available
```

## Scientific restrictions

```text
No Gold Proof
No Depth
No 100%
No Gold Target
Surface screening only
Field-check only
partial ready analyzed ground grid from Landsat/DEM
```

## Android assets policy

No GeoTIFF/TIFF/DEM/ZIP/JP2/MBTiles/PMTiles are placed inside Android assets.
