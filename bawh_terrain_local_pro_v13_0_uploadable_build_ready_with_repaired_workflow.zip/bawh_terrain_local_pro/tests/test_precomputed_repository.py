import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "apps" / "api"))

from app.bouh_core.precomputed_repository import get_radar_bootstrap_payload

def test_radar_bootstrap_has_targets(monkeypatch):
    monkeypatch.setenv("BOUH_PRECOMPUTED_DIR", str(ROOT / "data" / "precomputed"))
    payload = get_radar_bootstrap_payload()
    assert payload["ok"] is True
    assert len(payload["official_targets"]) >= 5
    assert payload["truth_policy"]["no_gold_proof"] is True
