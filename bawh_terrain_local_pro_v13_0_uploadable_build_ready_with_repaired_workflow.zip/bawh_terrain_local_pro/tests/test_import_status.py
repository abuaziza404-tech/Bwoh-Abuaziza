from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "apps" / "api"))

from app.bouh_core.import_status import scan_imports

def test_scan_imports_empty_tmp(tmp_path):
    out = scan_imports(tmp_path)
    assert out["ok"] is True
    assert out["count"] == 0

def test_scan_imports_classifies_png(tmp_path):
    p = tmp_path / "Browser_images_test.png"
    p.write_bytes(b"fake")
    out = scan_imports(tmp_path)
    assert out["count"] == 1
    assert out["items"][0]["evidence_class"] == "visual_context_only"
