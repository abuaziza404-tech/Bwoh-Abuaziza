from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "apps" / "api"))

from app.bouh_core.live_score_repository import live_score, live_score_status

def test_live_score_seed_context(monkeypatch):
    monkeypatch.setenv("BOUH_PRECOMPUTED_DIR", str(ROOT / "data" / "precomputed"))
    out = live_score(19.9732, 36.7456, 300)
    assert out["ok"] is True
    assert out["mode"] in {"seed_context_only", "ground_grid"}
    assert "Gold" not in out.get("limitation_ar", "")

def test_live_score_no_data(monkeypatch):
    monkeypatch.setenv("BOUH_PRECOMPUTED_DIR", str(ROOT / "data" / "precomputed"))
    out = live_score(0.0, 0.0, 50)
    assert out["ok"] is False
    assert out["mode"] == "no_data"

def test_live_score_status(monkeypatch):
    monkeypatch.setenv("BOUH_PRECOMPUTED_DIR", str(ROOT / "data" / "precomputed"))
    out = live_score_status()
    assert out["ok"] is True
    assert out["seed_cells_count"] >= 1
