# QA_CHECKLIST.md

## Backend

- [ ] `python -m py_compile` لكل ملفات app.
- [ ] `pytest -q`.
- [ ] `/app/identity`.
- [ ] `/radar/library`.
- [ ] `/radar/corridor`.
- [ ] `/projects/{id}/report/json`.
- [ ] `/projects/{id}/report/html`.
- [ ] `/data-manager/inspect-upload`.

## Frontend

- [ ] `npm install`.
- [ ] `npm run build`.
- [ ] Bottom nav: الرئيسية، الرادار، المكتبة، السلامة، التقارير، المصادر، الأمان.
- [ ] Badge المطور ثابت.
- [ ] Radar MapLibre.
- [ ] Layer toggles/opacities.
- [ ] Report Page.

## Android

- [ ] `npx cap add android`.
- [ ] `npx cap sync android`.
- [ ] `bash scripts/build_android_debug.sh`.
- [ ] `bash scripts/build_android_release.sh`.

## Security

- [ ] `.env` لا يحتوي أسرار Git.
- [ ] keystore خارج Git.
- [ ] uploads لا تقبل امتدادات خطرة.
- [ ] لا توجد عبارات كشف ذهب/دفائن/عمق مؤكد.
