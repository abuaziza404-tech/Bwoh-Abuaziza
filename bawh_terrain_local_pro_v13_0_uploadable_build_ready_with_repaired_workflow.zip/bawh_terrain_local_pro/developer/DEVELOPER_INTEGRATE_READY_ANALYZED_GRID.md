# تعليمات المطور — دمج البيانات المحللة الجاهزة

هذه ليست Manifest. هذه بيانات محللة جاهزة.

## انسخ

من الحزمة:

`data/precomputed/bouh_ground_grid.sqlite`

إلى المشروع:

`data/precomputed/bouh_ground_grid.sqlite`

## تحقق

```bash
sqlite3 data/precomputed/bouh_ground_grid.sqlite "select count(*) from ground_cells;"
```

يجب أن تكون النتيجة:

```text
4303
```

## شغل API

```bash
curl "http://localhost:8000/bouh/live-score/status"
curl "http://localhost:8000/bouh/live-score?lat=19.9732&lng=36.7456&radius=300"
```

## مهم

- لا تعيد تسميتها seed_context.
- هذه ground_grid جزئية محسوبة من Landsat/DEM.
- لا تدّعي NDVI/SWIR الحقيقي.
- لا Gold Proof.
- لا Depth.
- لا 100%.
- لا تضف الراسترات الثقيلة إلى Android assets.

## عند توفر Sentinel raw bands لاحقًا

أعد بناء نسخة v12.7 لإنتاج:
- true NDVI
- true NDWI
- true BSI
- true NDMI
- true SWIR
