from datetime import datetime, timezone

def clamp(v, mn=0, mx=100): return max(mn, min(mx, v))
def level(score): return "critical" if score>=75 else "high" if score>=55 else "medium" if score>=35 else "low"
def level_ar(l): return {"low":"منخفض","medium":"متوسط","high":"مرتفع","critical":"حرج"}.get(l,"غير معروف")
def build(name,label,score,msg):
    s=clamp(score); l=level(s)
    return {"name":name,"label_ar":label,"score":s,"level":l,"message_ar":f"{msg} مستوى الخطر: {level_ar(l)}."}
def maxh(hourly,key,default=0.0):
    vals=[float(v) for v in (hourly.get(key) or []) if v is not None]
    return max(vals) if vals else default
def meanh(hourly,key,default=0.0):
    vals=[float(v) for v in (hourly.get(key) or []) if v is not None]
    return sum(vals)/len(vals) if vals else default

def analyze_safety_forecast(raw):
    c=raw.get("current",{}) or {}; h=raw.get("hourly",{}) or {}
    max_temp=maxh(h,"temperature_2m",float(c.get("temperature_2m") or 0))
    max_wind=maxh(h,"wind_speed_10m",float(c.get("wind_speed_10m") or 0))
    max_gust=maxh(h,"wind_gusts_10m",float(c.get("wind_gusts_10m") or 0))
    max_prob=maxh(h,"precipitation_probability",0)
    max_precip=maxh(h,"precipitation",0)
    visibility=meanh(h,"visibility",10000)
    soil=meanh(h,"soil_moisture_0_to_1cm",0)
    heat=clamp((max_temp-32)*7.5); wind=clamp(max(max_wind*2.2,max_gust*1.6))
    flood=clamp(max_prob*.45+max_precip*7+soil*45); vis=clamp((10000-visibility)/100)
    field=clamp(heat*.25+wind*.25+flood*.35+vis*.15)
    risks=[build("heat","خطر الحرارة",heat,f"أعلى حرارة متوقعة {max_temp:.1f}°C."),
           build("wind","خطر الرياح",wind,f"أعلى سرعة رياح {max_wind:.1f} كم/س، وهبات {max_gust:.1f} كم/س."),
           build("flash_flood","خطر السيول والأمطار",flood,f"احتمال هطول أقصى {max_prob:.0f}%، وأعلى هطول {max_precip:.1f} مم."),
           build("visibility","خطر انخفاض الرؤية",vis,f"متوسط الرؤية {visibility:.0f} متر."),
           build("field_safety","سلامة العمل الميداني",field,"تقييم مركب.")]
    high=max(risks,key=lambda x:x["score"])
    return {"ok":True,"source":"open-meteo-live","online":True,"generated_at":datetime.now(timezone.utc).isoformat(),"risks":risks,"summary_ar":f"أعلى خطر: {high['label_ar']} بدرجة {high['score']:.0f}/100. {high['message_ar']}","raw":raw}

def offline_safety_response(lat,lng,cached_raw=None):
    if cached_raw:
        a=analyze_safety_forecast(cached_raw); a["source"]="local-cache"; a["online"]=False; a["summary_ar"]="استخدام آخر نسخة محفوظة. "+a["summary_ar"]; return a
    return {"ok":True,"source":"offline-placeholder","online":False,"generated_at":datetime.now(timezone.utc).isoformat(),"risks":[build("offline","لا توجد بيانات مباشرة",35,"لا يوجد اتصال ولا Cache.")],"summary_ar":"يعمل التطبيق بدون إنترنت، لكن تنبؤات الطقس تحتاج اتصالًا أو Cache.","raw":{}}
