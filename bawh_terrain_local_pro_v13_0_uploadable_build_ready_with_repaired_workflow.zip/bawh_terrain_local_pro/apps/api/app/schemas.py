from pydantic import BaseModel, Field

class CreateScanProjectRequest(BaseModel):
    name: str = Field(min_length=2, max_length=180)
    center_lat: float = Field(ge=-90, le=90)
    center_lng: float = Field(ge=-180, le=180)
    radius_m: float = Field(default=300.0, ge=10, le=10000)
    soil_type: str = Field(default="غير محدد", max_length=80)
    terrain_type: str = Field(default="غير محدد", max_length=80)

class ScanProjectResponse(BaseModel):
    id: int
    name: str
    center_lat: float
    center_lng: float
    radius_m: float
    soil_type: str
    terrain_type: str
    status: str
    class Config:
        from_attributes = True

class TerrainMetricsResponse(BaseModel):
    project_id: int
    mean_elevation: float
    min_elevation: float
    max_elevation: float
    mean_slope: float
    max_slope: float
    roughness_score: float
    moisture_proxy_score: float
    flow_score: float
    data_quality_score: float
    final_score: float
    report_ar: str
    layer_urls: dict
    source_metadata: dict
    class Config:
        from_attributes = True

class RadarScanRequest(BaseModel):
    project_id: int
    center_lat: float = Field(ge=-90, le=90)
    center_lng: float = Field(ge=-180, le=180)
    radius_m: float = Field(ge=10, le=10000)
    resolution_mode: str = Field(default="high")
    enabled_layers: list[str] = Field(default_factory=list)

class CreateAIAnalysisJobRequest(BaseModel):
    project_id: int | None = None
    dataset_role: str = Field(min_length=2, max_length=120)
    dataset_name: str = Field(min_length=2, max_length=260)
    task_type: str = Field(min_length=2, max_length=120)
    model_name: str = Field(default="pending_external_model", max_length=120)
    priority: str = Field(default="normal", max_length=40)
    input_metadata: dict = Field(default_factory=dict)
    notes_ar: str = Field(default="", max_length=2000)

class AIAnalysisJobResponse(BaseModel):
    id: int
    project_id: int | None
    dataset_role: str
    dataset_name: str
    task_type: str
    model_name: str
    priority: str
    status: str
    input_metadata: dict
    model_output: dict
    confidence: float | None
    human_review_status: str
    notes_ar: str
    class Config:
        from_attributes = True


class BootstrapAdminRequest(BaseModel):
    username: str = Field(min_length=3, max_length=120)
    password: str = Field(min_length=8, max_length=120)


class LoginRequest(BaseModel):
    username: str = Field(min_length=3, max_length=120)
    password: str = Field(min_length=1, max_length=120)


class AuthTokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    username: str


class UserResponse(BaseModel):
    id: int
    username: str
    role: str
    is_active: bool

    class Config:
        from_attributes = True


class CreateOfflineMapDownloadJobRequest(BaseModel):
    name: str = Field(min_length=2, max_length=260)
    source: str = Field(default="esri_satellite", max_length=80)
    west: float = Field(ge=-180, le=180)
    south: float = Field(ge=-90, le=90)
    east: float = Field(ge=-180, le=180)
    north: float = Field(ge=-90, le=90)
    min_zoom: int = Field(default=11, ge=0, le=22)
    max_zoom: int = Field(default=16, ge=0, le=22)
    include_reference: bool = True
    include_streets: bool = True


class OfflineMapDownloadJobResponse(BaseModel):
    id: int
    name: str
    source: str
    status: str
    west: float
    south: float
    east: float
    north: float
    min_zoom: int
    max_zoom: int
    estimated_tiles: int
    downloaded_tiles: int
    failed_tiles: int
    metadata_json: dict

    class Config:
        from_attributes = True


class EmergencyForecastRequest(BaseModel):
    lat: float = Field(ge=-90, le=90)
    lng: float = Field(ge=-180, le=180)
    radius_km: float = Field(default=50, ge=1, le=500)
    hours: int = Field(default=72, ge=1, le=168)
    include_satellite_feeds: bool = True


class EmergencyAlertEventResponse(BaseModel):
    id: int | None = None
    source: str
    event_type: str
    severity: str
    title_ar: str
    message_ar: str
    lat: float | None = None
    lng: float | None = None
    confidence: float | None = None
    metadata_json: dict = Field(default_factory=dict)

    class Config:
        from_attributes = True
