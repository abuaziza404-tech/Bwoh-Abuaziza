from io import BytesIO
from minio import Minio
from minio.error import S3Error
from app.config import settings

def get_minio_client():
    return Minio(settings.minio_endpoint, access_key=settings.minio_access_key, secret_key=settings.minio_secret_key, secure=False)

def ensure_bucket():
    client=get_minio_client()
    try:
        if not client.bucket_exists(settings.minio_bucket):
            client.make_bucket(settings.minio_bucket)
    except S3Error as exc:
        raise RuntimeError(str(exc)) from exc

def upload_bytes(object_name, data: bytes, content_type: str):
    ensure_bucket()
    get_minio_client().put_object(settings.minio_bucket, object_name, BytesIO(data), len(data), content_type=content_type)
    return f"{settings.minio_public_endpoint}/{settings.minio_bucket}/{object_name}"
