from datetime import datetime, timezone
import math
from typing import Any


def build_emergency_sources_status() -> list[dict[str, Any]]:
    return [
        {
            "id": "copernicus_ems",
            "label_ar": "Copernicus EMS",
            "category": "satellite_emergency",
            "mode": "online",
            "priority": "critical",
            "configured": True,
            "enabled": True,
            "message_ar": "خرائط طوارئ وأضرار وكوارث عبر صور أقمار ومصادر جغرافية.",
        },
        {
            "id": "nasa_firms",
            "label_ar": "NASA FIRMS",
            "category": "fire_satellite",
            "mode": "online",
            "priority": "critical",
            "configured": True,
            "enabled": True,
            "message_ar": "رصد حرائق نشطة شبه فوري من MODIS/VIIRS عند توفر الإنترنت.",
        },
        {
            "id": "open_meteo_extreme",
            "label_ar": "Open-Meteo Extreme Forecast",
            "category": "weather_forecast",
            "mode": "hybrid",
            "priority": "high",
            "configured": True,
            "enabled": True,
            "message_ar": "توقعات مطر ورياح وحرارة ورؤية مع Cache محلي.",
        },
        {
            "id": "noaa_nws_alerts",
            "label_ar": "NOAA/NWS Alerts",
            "category": "weather_alerts",
            "mode": "online",
            "priority": "regional",
            "configured": True,
            "enabled": True,
            "message_ar": "تنبيهات رسمية للولايات المتحدة فقط عند وقوع الموقع داخل نطاق الخدمة.",
        },
        {
            "id": "local_safety_engine",
            "label_ar": "محرك السلامة المحلي",
            "category": "local_prediction",
            "mode": "local",
            "priority": "always",
            "configured": True,
            "enabled": True,
            "message_ar": "يعمل بدون إنترنت بالاعتماد على آخر Cache وبيانات التضاريس.",
        },
    ]


def forecast_emergency_risk(lat: float, lng: float, radius_km: float, hours: int, weather_raw: dict[str, Any] | None = None) -> dict[str, Any]:
    terrain_factor = calculate_terrain_factor(lat, lng)
    coastal_factor = calculate_red_sea_coastal_factor(lng)
    seasonal_factor = calculate_seasonal_factor()
    radius_factor = min(1.0, radius_km / 120)

    flash_flood_score = clamp(28 + terrain_factor * 24 + seasonal_factor * 18 + radius_factor * 10)
    wind_score = clamp(22 + coastal_factor * 22 + seasonal_factor * 12)
    heat_score = clamp(24 + max(0, (lat - 18)) * 1.5 + seasonal_factor * 20)
    wildfire_score = clamp(18 + heat_score * 0.35 + wind_score * 0.22)
    visibility_score = clamp(20 + wind_score * 0.25 + coastal_factor * 8)

    if weather_raw:
        hourly = weather_raw.get("hourly") or {}
        precipitation = max_number(hourly.get("precipitation"), 0)
        wind_gust = max_number(hourly.get("wind_gusts_10m"), 0)
        temperature = max_number(hourly.get("temperature_2m"), 0)
        visibility = min_number(hourly.get("visibility"), 10000)

        flash_flood_score = clamp(flash_flood_score + precipitation * 8)
        wind_score = clamp(wind_score + max(0, wind_gust - 35) * 1.5)
        heat_score = clamp(heat_score + max(0, temperature - 38) * 2)
        visibility_score = clamp(visibility_score + max(0, 5000 - visibility) / 80)
        wildfire_score = clamp(wildfire_score + max(0, temperature - 35) * 1.5 + max(0, wind_gust - 30))

    risks = [
        risk("flash_flood", "سيول وانجراف أودية", flash_flood_score, "راقب مجاري الأودية والمنحدرات قبل الحركة الميدانية."),
        risk("wind_dust", "رياح وغبار", wind_score, "ثبّت المعدات وتجنب الطائرات المسيرة عند ارتفاع الرياح."),
        risk("heat_stress", "إجهاد حراري", heat_score, "خطط العمل في ساعات أبرد وتأكد من توفر مياه ومظلّة."),
        risk("wildfire", "حرائق سطحية", wildfire_score, "تجنب مصادر الشرر وراقب البلاغات الحرارية."),
        risk("visibility", "انخفاض رؤية", visibility_score, "استخدم مسارات واضحة وقلل سرعة الحركة في الغبار أو الضباب."),
    ]

    overall = max(item["score"] for item in risks)
    level = risk_level(overall)

    return {
        "ok": True,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "lat": lat,
        "lng": lng,
        "radius_km": radius_km,
        "hours": hours,
        "overall_score": overall,
        "overall_level": level,
        "summary_ar": summarize(level, overall),
        "risks": risks,
        "recommended_actions": recommended_actions(level),
        "sources": build_emergency_sources_status(),
    }


def risk(name: str, label_ar: str, score: float, message_ar: str) -> dict[str, Any]:
    return {
        "name": name,
        "label_ar": label_ar,
        "score": round(score, 2),
        "level": risk_level(score),
        "message_ar": message_ar,
    }


def risk_level(score: float) -> str:
    if score >= 80:
        return "critical"
    if score >= 60:
        return "high"
    if score >= 35:
        return "moderate"
    return "low"


def summarize(level: str, score: float) -> str:
    if level == "critical":
        return f"مؤشر طوارئ حرج {score:.0f}/100. أوقف العمل غير الضروري وراجع مصادر الطوارئ المتصلة."
    if level == "high":
        return f"مؤشر طوارئ مرتفع {score:.0f}/100. نفّذ خطة سلامة وتحقق من الأقمار والطقس قبل الحركة."
    if level == "moderate":
        return f"مؤشر طوارئ متوسط {score:.0f}/100. العمل ممكن مع مراقبة مستمرة."
    return f"مؤشر طوارئ منخفض {score:.0f}/100. لا توجد مؤشرات عالية في نموذج التنبؤ المحلي."


def recommended_actions(level: str) -> list[str]:
    common = [
        "احفظ المنطقة والخرائط Offline قبل الخروج.",
        "فعّل GPS الجهاز وخطة رجوع واضحة.",
        "راجع مصدر Copernicus EMS/NASA FIRMS عند توفر الإنترنت.",
    ]
    if level in {"critical", "high"}:
        return [
            "أوقف العمل الميداني غير الضروري.",
            "ابتعد عن مجاري الأودية والمنحدرات.",
            "لا تعتمد على نموذج واحد؛ راجع مصادر الطوارئ الرسمية.",
            *common,
        ]
    return common


def calculate_terrain_factor(lat: float, lng: float) -> float:
    return abs(math.sin(math.radians(lat * 2.7)) * math.cos(math.radians(lng * 1.9)))


def calculate_red_sea_coastal_factor(lng: float) -> float:
    return clamp01(1 - abs(lng - 38.5) / 8)


def calculate_seasonal_factor() -> float:
    month = datetime.now(timezone.utc).month
    if month in {7, 8, 9}:
        return 0.9
    if month in {4, 5, 10, 11}:
        return 0.65
    return 0.42


def max_number(values: Any, default: float) -> float:
    if not isinstance(values, list) or not values:
        return default
    nums = [float(value) for value in values if isinstance(value, (int, float))]
    return max(nums) if nums else default


def min_number(values: Any, default: float) -> float:
    if not isinstance(values, list) or not values:
        return default
    nums = [float(value) for value in values if isinstance(value, (int, float))]
    return min(nums) if nums else default


def clamp(value: float) -> float:
    return max(0, min(100, value))


def clamp01(value: float) -> float:
    return max(0, min(1, value))
