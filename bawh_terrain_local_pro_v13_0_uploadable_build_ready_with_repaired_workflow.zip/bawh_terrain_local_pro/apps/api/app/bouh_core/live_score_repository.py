from __future__ import annotations

import json
import math
import os
import sqlite3
from pathlib import Path
from typing import Any

def _root() -> Path:
    return Path(os.getenv("BOUH_PRECOMPUTED_DIR", "data/precomputed"))

def _distance_m(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lng2 - lng1)
    a = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 2*r*math.atan2(math.sqrt(a), math.sqrt(1-a))

def _load_seed_cells() -> list[dict[str, Any]]:
    json_path = _root() / "bouh_seed_cells_v12_5.json"
    if json_path.exists():
        return json.loads(json_path.read_text(encoding="utf-8")).get("seed_cells", [])

    sqlite_path = _root() / "bouh_seed_cells_v12_5.sqlite"
    if sqlite_path.exists():
        conn = sqlite3.connect(sqlite_path)
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute("SELECT * FROM seed_cells").fetchall()
        finally:
            conn.close()

        cells: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            payload = item.get("payload_json")
            if payload:
                try:
                    item.update(json.loads(payload))
                except Exception:
                    pass
            cells.append(item)
        return cells

    return []

def _nearest_seed(lat: float, lng: float, radius_m: float) -> dict[str, Any] | None:
    best = None
    best_d = None
    for s in _load_seed_cells():
        d = _distance_m(lat, lng, float(s["latitude"]), float(s["longitude"]))
        if d <= radius_m and (best_d is None or d < best_d):
            best = dict(s)
            best_d = d
    if best is not None:
        best["distance_m"] = round(best_d or 0, 2)
    return best

def _nearest_ground_cell(lat: float, lng: float, radius_m: float) -> dict[str, Any] | None:
    db = _root() / "bouh_ground_grid.sqlite"
    if not db.exists():
        return None
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    # Bounding-box prefilter. Approx degrees.
    dlat = radius_m / 111320.0
    dlng = radius_m / (111320.0 * max(0.2, math.cos(math.radians(lat))))
    rows = cur.execute("""
      SELECT * FROM ground_cells
      WHERE latitude BETWEEN ? AND ?
        AND longitude BETWEEN ? AND ?
      LIMIT 500
    """, (lat-dlat, lat+dlat, lng-dlng, lng+dlng)).fetchall()
    conn.close()
    best = None
    best_d = None
    for row in rows:
        item = dict(row)
        payload = item.get("payload_json")
        if payload:
            try:
                item.update(json.loads(payload))
            except Exception:
                pass
        d = _distance_m(lat, lng, float(item["latitude"]), float(item["longitude"]))
        if d <= radius_m and (best_d is None or d < best_d):
            best = item
            best_d = d
    if best:
        best["distance_m"] = round(best_d or 0, 2)
    return best

def live_score(lat: float, lng: float, radius_m: float = 300) -> dict[str, Any]:
    ground = _nearest_ground_cell(lat, lng, radius_m)
    if ground and ground.get("final_ground_score") is not None:
        return {
            "ok": True,
            "mode": "ground_grid",
            "result": ground,
            "truth_status": ground.get("truth_status", "partial_ready_analyzed_ground_grid_landsat_dem"),
            "limitation_ar": ground.get("limitation_ar", "تحليل خلايا جاهز حسب دقة وتقطيع مصادر Landsat/DEM المتاحة. لا يوجد Gold Proof ولا Depth ولا 100%.")
        }

    seed = _nearest_seed(lat, lng, radius_m)
    if seed:
        return {
            "ok": True,
            "mode": "seed_context_only",
            "result": seed,
            "truth_status": "precomputed_seed_context_only",
            "limitation_ar": "هذه نتيجة سياقية من نقطة seed قريبة، وليست قراءة بيكسل خام. ابنِ bouh_ground_grid.sqlite للحصول على قراءة أرض حقيقية."
        }

    return {
        "ok": False,
        "mode": "no_data",
        "truth_status": "no_ground_grid_cell",
        "limitation_ar": "لا توجد شبكة تحليل أرضي محسوبة أو نقطة seed ضمن نصف القطر. لا يجوز اختراع نتيجة.",
        "lat": lat,
        "lng": lng,
        "radius_m": radius_m
    }

def live_score_status() -> dict[str, Any]:
    root = _root()
    grid = root / "bouh_ground_grid.sqlite"
    seed = root / "bouh_seed_cells_v12_5.json"
    seed_sqlite = root / "bouh_seed_cells_v12_5.sqlite"
    status = {
        "ok": True,
        "precomputed_dir": str(root),
        "ground_grid_exists": grid.exists(),
        "seed_cells_exists": seed.exists() or seed_sqlite.exists(),
        "seed_cells_json_exists": seed.exists(),
        "seed_cells_sqlite_exists": seed_sqlite.exists(),
        "truth_rule": "No Gold Proof. No depth. No synthetic high confidence. Never evaluate on FeOx alone.",
        "analysis_type": "partial_ready_analyzed_ground_grid_or_seed_context",
        "source_family": "Landsat/DEM if bouh_ground_grid.sqlite has rows; seed_context_only otherwise"
    }
    if seed.exists() or seed_sqlite.exists():
        status["seed_cells_count"] = len(_load_seed_cells())
    if grid.exists():
        conn = sqlite3.connect(grid)
        try:
            count = conn.execute("SELECT COUNT(*) FROM ground_cells").fetchone()[0]
        except Exception:
            count = None
        finally:
            conn.close()
        status["ground_grid_cell_count"] = count
    return status
