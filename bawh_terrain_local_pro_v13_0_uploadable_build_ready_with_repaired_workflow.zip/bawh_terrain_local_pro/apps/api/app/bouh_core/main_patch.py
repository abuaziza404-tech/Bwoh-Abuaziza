# Add this to apps/api/app/main.py

from app.bouh_core.router import router as bouh_lightweight_router

app.include_router(bouh_lightweight_router)
