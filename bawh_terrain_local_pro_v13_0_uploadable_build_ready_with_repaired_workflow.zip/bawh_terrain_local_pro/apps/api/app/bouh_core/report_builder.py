from html import escape
from typing import Any
from .decision_rules import decide_target_priority
from .gpz_strategy import recommend_gpz_strategy
from .field_templates import SCIENTIFIC_DISCLAIMER_AR, FIELD_ACTIONS_AR


def safe(value: Any, default: str = "غير متوفر") -> str:
    if value in [None, "", [], {}]:
        return default
    return str(value)


def build_project_report_json(project: dict, metrics: dict | None = None, sources: dict | None = None, safety: dict | None = None, evidence: dict | None = None) -> dict:
    metrics = metrics or {}
    sources = sources or {}
    safety = safety or {}
    evidence = evidence or {"source": "synthetic_fallback"}

    decision = decide_target_priority(evidence)
    gpz = recommend_gpz_strategy(evidence.get("magnetic_ground_risk"), evidence.get("quartz_qi"))
    target_class = decision["target_priority"]

    report = {
        "app_name": "بوح التضاريس | منظومة أبوعزيزة",
        "platform_name": "BOUH Terrain Intelligence Platform",
        "project_name": safe(project.get("name")),
        "analysis_location": {
            "lat": project.get("center_lat"),
            "lng": project.get("center_lng"),
            "radius_m": project.get("radius_m"),
        },
        "data_source": safe(sources.get("data_source"), "local_project"),
        "source_status": sources.get("source_status", "mixed/offline-first"),
        "dem_source": safe(sources.get("dem_source"), metrics.get("dem_source") or "synthetic_fallback"),
        "sentinel_source": safe(sources.get("sentinel_source"), "manual_upload_or_credentials_required"),
        "soil_source": safe(sources.get("soil_source"), "optional_external_api"),
        "osm_source": safe(sources.get("osm_source"), "optional_external_api"),
        "weather_source": safe(safety.get("source"), "open_meteo_or_cache"),
        "raster_layers": metrics.get("raster_layers", []),
        "spectral_summaries": {
            "ndvi": metrics.get("ndvi"),
            "ndwi": metrics.get("ndwi"),
            "bsi": metrics.get("bsi"),
            "ndmi": metrics.get("ndmi"),
        },
        "terrain_signature": {
            "elevation_min": metrics.get("min_elevation"),
            "elevation_max": metrics.get("max_elevation"),
            "elevation_mean": metrics.get("mean_elevation"),
            "slope_mean": metrics.get("mean_slope"),
            "roughness_score": metrics.get("roughness_score"),
            "flow_score": metrics.get("flow_score"),
        },
        "spectral_fingerprint": evidence.get("spectral_fingerprint", "غير كافٍ بدون باندات موثقة."),
        "structure_evidence": evidence.get("structure_evidence", False),
        "alteration_evidence": evidence.get("alteration_evidence", False),
        "magnetic_ground_risk": evidence.get("magnetic_ground_risk"),
        "target_priority": target_class,
        "decision": decision,
        "gpz_field_strategy": gpz,
        "safety_forecast": safety,
        "reject_reason": decision["reasons_ar"] if target_class in {"Reject", "Needs More Data"} else [],
        "recommended_field_action": FIELD_ACTIONS_AR.get(target_class, FIELD_ACTIONS_AR["Needs More Data"]),
        "disclaimer_ar": "هذا تحليل سطحي احتمالي ولا يثبت وجود أهداف تحت الأرض.",
        "scientific_guardrail_ar": SCIENTIFIC_DISCLAIMER_AR,
    }
    return report


def build_project_report_html(report: dict) -> str:
    title = escape(safe(report.get("project_name"), "تقرير بوح التضاريس"))
    rows = []
    for key, value in flatten_report(report).items():
        rows.append(f"<tr><th>{escape(key)}</th><td>{escape(safe(value))}</td></tr>")

    return f"""<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>{title}</title>
<style>
body{{font-family:system-ui,-apple-system,Segoe UI,sans-serif;background:#07110f;color:#eafff6;margin:0;padding:24px;}}
main{{max-width:980px;margin:auto;background:#10241f;border:1px solid rgba(143,255,211,.16);border-radius:24px;padding:22px;}}
h1{{margin-top:0;color:#20e28a;}}
p{{line-height:1.8;color:#8fb8aa;}}
table{{width:100%;border-collapse:collapse;margin-top:18px;}}
th,td{{border:1px solid rgba(143,255,211,.16);padding:10px;vertical-align:top;}}
th{{width:280px;color:#f2c14e;text-align:right;}}
.badge{{display:inline-block;background:#20e28a;color:#041510;border-radius:999px;padding:8px 12px;font-weight:900;}}
.disclaimer{{margin-top:20px;border:1px solid #f2c14e;border-radius:16px;padding:14px;color:#f2c14e;}}
</style>
</head>
<body><main>
<span class="badge">BOUH Terrain Intelligence Platform</span>
<h1>{title}</h1>
<p>المطور المعتمد: أحمد أبوعزيزة الرشيدي — Ahmed Abuaziza Al-Rashidi</p>
<table>{''.join(rows)}</table>
<div class="disclaimer">{escape(report.get("scientific_guardrail_ar") or report.get("disclaimer_ar") or "")}</div>
</main></body></html>"""


def flatten_report(report: dict, prefix: str = "") -> dict:
    out: dict[str, Any] = {}
    for key, value in report.items():
        label = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            out.update(flatten_report(value, label))
        elif isinstance(value, list):
            out[label] = " | ".join(str(item) for item in value)
        else:
            out[label] = value
    return out
