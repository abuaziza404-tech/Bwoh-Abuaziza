from dataclasses import dataclass
from typing import Any

ALLOWED_EVIDENCE_SOURCES = [
    "uploaded_geotiff",
    "real_raster",
    "field_input",
    "external_api",
    "local_cache",
    "visual_only",
    "synthetic_fallback",
    "example",
]

INSUFFICIENT_DATA_AR = "لا توجد بيانات كافية لحساب هذا رقمياً."

RESTRICTED_NUMERIC_NAMES = {
    "ndvi",
    "ndwi",
    "bsi",
    "ndmi",
    "depth",
    "gold_percentage",
    "confidence_high",
    "target_coordinate",
}


@dataclass(frozen=True)
class EvidenceValue:
    name: str
    value: Any
    source: str
    status: str = "provided"
    message_ar: str = ""


def is_allowed_source(source: str | None) -> bool:
    return bool(source) and str(source) in ALLOWED_EVIDENCE_SOURCES


def is_numeric_evidence_source(source: str | None) -> bool:
    return source in {"uploaded_geotiff", "real_raster", "field_input", "external_api", "local_cache"}


def guard_value(name: str, value: Any, source: str | None) -> EvidenceValue:
    normalized = name.strip().lower()

    if not is_allowed_source(source):
        return EvidenceValue(name=name, value=None, source="unknown", status="blocked", message_ar=INSUFFICIENT_DATA_AR)

    if normalized in RESTRICTED_NUMERIC_NAMES and not is_numeric_evidence_source(source):
        return EvidenceValue(name=name, value=None, source=str(source), status="blocked", message_ar=INSUFFICIENT_DATA_AR)

    if normalized in {"depth", "gold_percentage"}:
        return EvidenceValue(
            name=name,
            value=None,
            source=str(source),
            status="blocked",
            message_ar="النظام لا ينتج عمقاً أو نسبة ذهب أو إثباتاً لما تحت الأرض.",
        )

    return EvidenceValue(name=name, value=value, source=str(source), status="accepted", message_ar="مقبول")


def guard_numeric(name: str, value: Any, source: str | None) -> dict:
    evidence = guard_value(name, value, source)

    if evidence.status != "accepted":
        return evidence.__dict__

    try:
        number = float(value)
    except Exception:
        return EvidenceValue(name=name, value=None, source=str(source), status="blocked", message_ar=INSUFFICIENT_DATA_AR).__dict__

    return EvidenceValue(name=name, value=number, source=str(source), status="accepted", message_ar="مقبول").__dict__


def guard_coordinates(lat: Any, lng: Any, source: str | None) -> dict:
    if not is_numeric_evidence_source(source):
        return {
            "lat": None,
            "lng": None,
            "source": source or "unknown",
            "status": "blocked",
            "message_ar": "لا يمكن إخراج إحداثيات هدف جديدة بلا مصدر رقمي أو إدخال ميداني موثق.",
        }

    try:
        lat_f = float(lat)
        lng_f = float(lng)
    except Exception:
        return {"lat": None, "lng": None, "source": source, "status": "blocked", "message_ar": INSUFFICIENT_DATA_AR}

    if not (-90 <= lat_f <= 90 and -180 <= lng_f <= 180):
        return {"lat": None, "lng": None, "source": source, "status": "blocked", "message_ar": "الإحداثيات خارج النطاق الصحيح."}

    return {"lat": lat_f, "lng": lng_f, "source": source, "status": "accepted", "message_ar": "مقبول"}


def summarize_sources(values: list[dict]) -> dict:
    summary = {source: 0 for source in ALLOWED_EVIDENCE_SOURCES}
    summary["blocked"] = 0
    for item in values:
        if item.get("status") == "blocked":
            summary["blocked"] += 1
        source = item.get("source")
        if source in summary:
            summary[source] += 1
    return summary
