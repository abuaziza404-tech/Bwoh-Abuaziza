APP_IDENTITY = {
    "app_name": "بوح التضاريس",
    "app_version": "2.0.0-local-pro",
    "developer_name_ar": "أحمد أبوعزيزة الرشيدي",
    "developer_name_en": "Ahmed Abuaziza Al-Rashidi",
    "security_profile": "Offline-first, signed local data, restricted uploads, audit logging",
    "disclaimer_ar": "النظام لتحليل التضاريس والطقس والطبقات السطحية وإدارة السلامة. لا يثبت وجود أهداف تحت الأرض.",
}
