from datetime import datetime
from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, String, Text, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from geoalchemy2 import Geometry
from app.database import Base

class ScanProject(Base):
    __tablename__ = "scan_projects"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(180), nullable=False)
    center_lat: Mapped[float] = mapped_column(Float, nullable=False)
    center_lng: Mapped[float] = mapped_column(Float, nullable=False)
    radius_m: Mapped[float] = mapped_column(Float, nullable=False, default=300.0)
    soil_type: Mapped[str] = mapped_column(String(80), nullable=False, default="غير محدد")
    terrain_type: Mapped[str] = mapped_column(String(80), nullable=False, default="غير محدد")
    status: Mapped[str] = mapped_column(String(50), nullable=False, default="queued")
    aoi: Mapped[str] = mapped_column(Geometry("POLYGON", srid=4326), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class TerrainMetrics(Base):
    __tablename__ = "terrain_metrics"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("scan_projects.id"), nullable=False)
    mean_elevation: Mapped[float] = mapped_column(Float, default=0.0)
    min_elevation: Mapped[float] = mapped_column(Float, default=0.0)
    max_elevation: Mapped[float] = mapped_column(Float, default=0.0)
    mean_slope: Mapped[float] = mapped_column(Float, default=0.0)
    max_slope: Mapped[float] = mapped_column(Float, default=0.0)
    roughness_score: Mapped[float] = mapped_column(Float, default=0.0)
    moisture_proxy_score: Mapped[float] = mapped_column(Float, default=0.0)
    flow_score: Mapped[float] = mapped_column(Float, default=0.0)
    data_quality_score: Mapped[float] = mapped_column(Float, default=0.0)
    final_score: Mapped[float] = mapped_column(Float, default=0.0)
    report_ar: Mapped[str] = mapped_column(Text, default="")
    layer_urls: Mapped[dict] = mapped_column(JSON, default=dict)
    source_metadata: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class ProjectUpload(Base):
    __tablename__ = "project_uploads"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("scan_projects.id"), nullable=False)
    file_name: Mapped[str] = mapped_column(String(260), nullable=False)
    object_name: Mapped[str] = mapped_column(String(360), nullable=False)
    local_path: Mapped[str] = mapped_column(String(500), nullable=True)
    content_type: Mapped[str] = mapped_column(String(120), nullable=False)
    file_size: Mapped[int] = mapped_column(Integer, nullable=False)
    band_role: Mapped[str] = mapped_column(String(40), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class RadarDataset(Base):
    __tablename__ = "radar_datasets"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("scan_projects.id"), nullable=False)
    name: Mapped[str] = mapped_column(String(260), nullable=False)
    dataset_type: Mapped[str] = mapped_column(String(80), nullable=False, default="browser_images_zip")
    original_file_name: Mapped[str] = mapped_column(String(260), nullable=False)
    object_name: Mapped[str] = mapped_column(String(360), nullable=False)
    local_zip_path: Mapped[str] = mapped_column(String(500), nullable=False)
    extract_dir: Mapped[str] = mapped_column(String(500), nullable=False)
    file_count: Mapped[int] = mapped_column(Integer, default=0)
    image_count: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(50), default="indexed")
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class RadarDatasetAsset(Base):
    __tablename__ = "radar_dataset_assets"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    dataset_id: Mapped[int] = mapped_column(ForeignKey("radar_datasets.id"), nullable=False)
    project_id: Mapped[int] = mapped_column(ForeignKey("scan_projects.id"), nullable=False)
    file_name: Mapped[str] = mapped_column(String(260), nullable=False)
    relative_path: Mapped[str] = mapped_column(String(500), nullable=False)
    local_path: Mapped[str] = mapped_column(String(500), nullable=False)
    content_type: Mapped[str] = mapped_column(String(120), nullable=False)
    sha256: Mapped[str] = mapped_column(String(80), nullable=False)
    width: Mapped[int | None] = mapped_column(Integer, nullable=True)
    height: Mapped[int | None] = mapped_column(Integer, nullable=True)
    gps_lat: Mapped[float | None] = mapped_column(Float, nullable=True)
    gps_lng: Mapped[float | None] = mapped_column(Float, nullable=True)
    asset_role: Mapped[str] = mapped_column(String(80), default="unclassified")
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class AIAnalysisJob(Base):
    __tablename__ = "ai_analysis_jobs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    project_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    dataset_role: Mapped[str] = mapped_column(String(120), nullable=False)
    dataset_name: Mapped[str] = mapped_column(String(260), nullable=False)
    task_type: Mapped[str] = mapped_column(String(120), nullable=False)
    model_name: Mapped[str] = mapped_column(String(120), nullable=False, default="pending_external_model")
    priority: Mapped[str] = mapped_column(String(40), nullable=False, default="normal")
    status: Mapped[str] = mapped_column(String(50), nullable=False, default="queued")
    input_metadata: Mapped[dict] = mapped_column(JSON, default=dict)
    model_output: Mapped[dict] = mapped_column(JSON, default=dict)
    confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    human_review_status: Mapped[str] = mapped_column(String(50), nullable=False, default="not_reviewed")
    notes_ar: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class OfflineMapPack(Base):
    __tablename__ = "offline_map_packs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(260), nullable=False)
    pack_type: Mapped[str] = mapped_column(String(30), nullable=False)
    file_name: Mapped[str] = mapped_column(String(260), nullable=False)
    local_path: Mapped[str] = mapped_column(String(500), nullable=False)
    file_size: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    min_zoom: Mapped[int | None] = mapped_column(Integer, nullable=True)
    max_zoom: Mapped[int | None] = mapped_column(Integer, nullable=True)
    bounds_json: Mapped[dict] = mapped_column(JSON, default=dict)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class AppUser(Base):
    __tablename__ = "app_users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    username: Mapped[str] = mapped_column(String(120), unique=True, nullable=False, index=True)
    password_hash: Mapped[str] = mapped_column(String(260), nullable=False)
    role: Mapped[str] = mapped_column(String(50), nullable=False, default="operator")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class OfflineMapDownloadJob(Base):
    __tablename__ = "offline_map_download_jobs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(260), nullable=False)
    source: Mapped[str] = mapped_column(String(80), nullable=False, default="esri_satellite")
    status: Mapped[str] = mapped_column(String(50), nullable=False, default="planned")
    west: Mapped[float] = mapped_column(Float, nullable=False)
    south: Mapped[float] = mapped_column(Float, nullable=False)
    east: Mapped[float] = mapped_column(Float, nullable=False)
    north: Mapped[float] = mapped_column(Float, nullable=False)
    min_zoom: Mapped[int] = mapped_column(Integer, nullable=False, default=11)
    max_zoom: Mapped[int] = mapped_column(Integer, nullable=False, default=16)
    estimated_tiles: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    downloaded_tiles: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    failed_tiles: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class EmergencyAlertEvent(Base):
    __tablename__ = "emergency_alert_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    source: Mapped[str] = mapped_column(String(120), nullable=False)
    event_type: Mapped[str] = mapped_column(String(120), nullable=False)
    severity: Mapped[str] = mapped_column(String(50), nullable=False, default="moderate")
    title_ar: Mapped[str] = mapped_column(String(260), nullable=False)
    message_ar: Mapped[str] = mapped_column(Text, default="")
    lat: Mapped[float | None] = mapped_column(Float, nullable=True)
    lng: Mapped[float | None] = mapped_column(Float, nullable=True)
    confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    starts_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    ends_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
