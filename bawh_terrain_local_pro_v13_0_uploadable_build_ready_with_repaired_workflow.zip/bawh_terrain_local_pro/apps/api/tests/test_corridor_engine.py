from app.bouh_core.corridor_engine import build_corridor_decision


def test_complete_corridor():
    items = [{"role": "regional_south"}, {"role": "regional_center"}, {"role": "regional_north"}]
    result = build_corridor_decision(items)
    assert result["corridor_status"] == "Regional Corridor"
    assert result["best_connected_segment"] == "regional_center"


def test_missing_center_is_disconnected():
    items = [{"role": "regional_south"}, {"role": "regional_north"}]
    result = build_corridor_decision(items)
    assert result["corridor_status"] == "Disconnected"
    assert "regional_center" in result["missing_segments"]
