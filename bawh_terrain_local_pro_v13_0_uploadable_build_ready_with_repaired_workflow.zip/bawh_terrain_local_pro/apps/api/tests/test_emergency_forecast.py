from app.emergency.forecast import build_emergency_sources_status, forecast_emergency_risk


def test_emergency_sources_include_core_feeds():
    sources = build_emergency_sources_status()
    ids = {item["id"] for item in sources}
    assert "copernicus_ems" in ids
    assert "nasa_firms" in ids
    assert "open_meteo_extreme" in ids


def test_emergency_forecast_shape():
    result = forecast_emergency_risk(24.7, 46.6, 50, 72)
    assert result["ok"] is True
    assert result["overall_score"] >= 0
    assert len(result["risks"]) >= 5
    assert result["summary_ar"]
