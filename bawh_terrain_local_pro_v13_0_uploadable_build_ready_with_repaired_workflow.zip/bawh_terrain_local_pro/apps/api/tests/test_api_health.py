from fastapi.testclient import TestClient

from app.main import app


def test_health_endpoint():
    client = TestClient(app)
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["ok"] is True


def test_identity_endpoint():
    client = TestClient(app)
    response = client.get("/app/identity")
    assert response.status_code == 200
    assert response.json()["developer_name_ar"] == "أحمد أبوعزيزة الرشيدي"
