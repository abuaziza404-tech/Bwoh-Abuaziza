import React, { useEffect, useState } from "react";

type LiveScorePayload = {
  ok: boolean;
  mode: string;
  truth_status?: string;
  limitation_ar?: string;
  result?: {
    final_ground_score?: number | null;
    class?: string;
    distance_m?: number;
    truth_status?: string;
    limitation_ar?: string;
    NDVI?: number;
    ndvi?: number;
    BSI?: number;
    bsi?: number;
    IRON_B04_B02?: number;
    iron_b04_b02?: number;
    SWIR_B11_B12?: number;
    swir_b11_b12?: number;
    evidence_count?: number;
    source?: string;
    refl_brightness?: number;
    refl_red_green_proxy?: number;
    tir_brightness?: number;
    dem_elevation?: number;
    slope_proxy?: number;
    terrain_score?: number;
    alteration_proxy_score?: number;
    dryness_exposure_score?: number;
    structure_score?: number;
  };
};

const API_BASE = import.meta.env.VITE_API_BASE ?? "http://localhost:8000";

export default function BouhLiveGroundScoreMeter({
  lat,
  lng,
  radius,
}: {
  lat: number;
  lng: number;
  radius: number;
}) {
  const [data, setData] = useState<LiveScorePayload | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;
    async function run() {
      setLoading(true);
      try {
        const url = `${API_BASE}/bouh/live-score?lat=${lat}&lng=${lng}&radius=${radius}`;
        const response = await fetch(url);
        const payload = await response.json();
        if (!cancelled) setData(payload);
      } catch {
        if (!cancelled) {
          setData({
            ok: false,
            mode: "api_unavailable",
            limitation_ar: "تعذر الوصول إلى Live Score API. لا توجد نتيجة محسوبة.",
          });
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    if (Number.isFinite(lat) && Number.isFinite(lng)) run();
    return () => { cancelled = true; };
  }, [lat, lng, radius]);

  const score = data?.result?.final_ground_score;
  const className = data?.result?.class ?? (data?.ok ? "Seed Context" : "No Data");

  return (
    <section className="bouh-live-meter">
      <header>
        <strong>Live Ground Score</strong>
        <small>{loading ? "جاري الحساب..." : data?.mode ?? "—"}</small>
      </header>
      <div className="meter">
        <div className="meter-value">{typeof score === "number" ? Math.round(score) : "—"}</div>
        <div className="meter-label">{className}</div>
      </div>
      <div className="meter-grid">
        <span>final_ground_score: {fmt(data?.result?.final_ground_score)}</span>
        <span>class: {className}</span>
        <span>evidence_count: {data?.result?.evidence_count ?? "—"}</span>
        <span>refl_brightness: {fmt(data?.result?.refl_brightness)}</span>
        <span>refl_red_green_proxy: {fmt(data?.result?.refl_red_green_proxy)}</span>
        <span>tir_brightness: {fmt(data?.result?.tir_brightness)}</span>
        <span>dem_elevation: {fmt(data?.result?.dem_elevation)}</span>
        <span>slope_proxy: {fmt(data?.result?.slope_proxy)}</span>
        <span>terrain_score: {fmt(data?.result?.terrain_score)}</span>
        <span>alteration_proxy_score: {fmt(data?.result?.alteration_proxy_score)}</span>
        <span>dryness_exposure_score: {fmt(data?.result?.dryness_exposure_score)}</span>
        <span>structure_score: {fmt(data?.result?.structure_score)}</span>
        <span>truth_status: {data?.truth_status ?? data?.result?.truth_status ?? "—"}</span>
        <span>Distance: {fmt(data?.result?.distance_m)} m</span>
      </div>
      <p className="meter-note">
        {data?.limitation_ar ?? data?.result?.limitation_ar ?? "ترجيح سطحي وليس إثبات ذهب."}
      </p>
      <div className="truth-policy">
        No Gold Proof · No depth · No 100% · Never evaluate on FeOx alone · No Structure + No Clay/Silica = Reject
      </div>
    </section>
  );
}

function fmt(v: unknown) {
  return typeof v === "number" ? v.toFixed(3) : "—";
}
