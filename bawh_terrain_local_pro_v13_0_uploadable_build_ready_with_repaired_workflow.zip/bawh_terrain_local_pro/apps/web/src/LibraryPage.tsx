import React, { useEffect, useState } from "react";
import { RadarLibraryItem, getRadarCorridor, getRadarLibrary } from "./api";

const ROLE_ORDER = ["regional_south","regional_center","regional_north","port_partial","local_target_west","local_target_east","abuziza_local_app"];

export default function LibraryPage({ onMessage }: { onMessage: (message: string) => void }) {
  const [items, setItems] = useState<RadarLibraryItem[]>([]);
  const [corridor, setCorridor] = useState<Record<string, unknown> | null>(null);
  const [selected, setSelected] = useState<string>("regional_center");

  useEffect(() => {
    load();
  }, []);

  async function load() {
    try {
      const [libraryResponse, corridorResponse] = await Promise.all([getRadarLibrary(), getRadarCorridor()]);
      const ordered = [...libraryResponse.items].sort((a,b) => ROLE_ORDER.indexOf(a.role) - ROLE_ORDER.indexOf(b.role));
      setItems(ordered);
      setCorridor(corridorResponse.corridor);
      if (ordered.length) setSelected(ordered[0].role);
      onMessage("تم تحميل مكتبة الرادار الإقليمية والممر.");
    } catch {
      onMessage("تعذر تحميل مكتبة الرادار.");
    }
  }

  const current = items.find((item) => item.role === selected) ?? items[0];

  return (
    <section className="screen">
      <article className="hero-card compact">
        <span className="eyebrow">مكتبة الرادار الإقليمية</span>
        <h2>South → Center → North مع السياقات المحلية</h2>
        <p>تعرض جنوب/وسط/شمال وPort والأهداف المحلية وسجل أبوعزيزة كـ Knowledge Register، دون اعتباره إثباتًا علميًا وحده.</p>
        <button className="primary" type="button" onClick={load}>تحديث المكتبة</button>
      </article>

      <div className="map-layer-tabs">
        {items.map((item) => (
          <button key={item.role} className={selected === item.role ? "active" : ""} onClick={() => setSelected(item.role)} type="button">
            {item.label_ar}
          </button>
        ))}
      </div>

      {current && (
        <article className="panel">
          <h3>{current.label_ar}</h3>
          <p>{current.recommendation_ar}</p>
          <div className="mini-metrics">
            <SmallMetric label="NDVI" value={current.ndvi_mean} />
            <SmallMetric label="NDWI" value={current.ndwi_mean} />
            <SmallMetric label="BSI" value={current.bsi_mean} />
            <SmallMetric label="NDMI" value={current.ndmi_mean} />
          </div>
          <div className="base-layer-meta">
            <span>{current.complete_core ? "مكتمل" : "جزئي"}</span>
            <span>{current.band_count} bands</span>
            <span>{current.analysis_status}</span>
          </div>
        </article>
      )}

      <article className="panel">
        <h3>محرك الممر الإقليمي</h3>
        <p>{String(corridor?.recommendation_ar ?? "لم يتم حساب الممر بعد.")}</p>
        <ul className="clean-list">
          <li>Center هو حلقة الربط الأساسية.</li>
          <li>Port سياق جزئي فقط.</li>
          <li>الأهداف المحلية سياق محلي.</li>
          <li>سجل أبوعزيزة المحلي Knowledge Register وليس إثباتًا علميًا وحده.</li>
        </ul>
      </article>
    </section>
  );
}

function SmallMetric({ label, value }: { label: string; value: number | null }) {
  return (
    <div className="small-metric">
      <span>{label}</span>
      <strong>{typeof value === "number" ? value.toFixed(3) : "—"}</strong>
    </div>
  );
}
