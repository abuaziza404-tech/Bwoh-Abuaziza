import React, { useEffect, useState } from "react";
import { DataManagerInspection, Project, getProjectReportHtmlUrl, getProjectReportJson, inspectDataManagerUpload } from "./api";

export default function ReportPage({
  project,
  onMessage
}: {
  project: Project | null;
  onMessage: (message: string) => void;
}) {
  const [report, setReport] = useState<Record<string, unknown> | null>(null);
  const [inspection, setInspection] = useState<DataManagerInspection | null>(null);

  useEffect(() => {
    if (project) loadReport();
  }, [project?.id]);

  async function loadReport() {
    if (!project) {
      onMessage("أنشئ مشروعًا أولًا لتوليد تقرير.");
      return;
    }

    try {
      const data = await getProjectReportJson(project.id);
      setReport(data);
      onMessage("تم توليد تقرير JSON للمشروع.");
    } catch {
      onMessage("لا يوجد تقرير بعد؛ شغّل التحليل أولًا.");
    }
  }

  async function inspect(file: File) {
    try {
      const result = await inspectDataManagerUpload(file);
      setInspection(result);
      onMessage(result.file.recommendation_ar);
    } catch {
      onMessage("فشل فحص الملف.");
    }
  }

  return (
    <section className="screen">
      <article className="hero-card compact">
        <span className="eyebrow">مركز التقارير وData Manager</span>
        <h2>تقرير عربي ميداني + فحص ملفات آمن</h2>
        <p>يدعم HTML/JSON، source metadata، السلامة، GPZ strategy، BOUH decision class، وتنبيه الصدق العلمي.</p>
        <div className="action-row">
          <button className="primary" type="button" onClick={loadReport}>إنشاء تقرير</button>
          {project && <a className="secondary link-button" href={getProjectReportHtmlUrl(project.id)} target="_blank" rel="noreferrer">فتح HTML</a>}
        </div>
      </article>

      <article className="panel upload-panel">
        <h3>Data Manager</h3>
        <p>Upload → Inspect → Classify → Validate → Store → Analyze → Report</p>
        <label className="upload">
          <input type="file" accept=".tif,.tiff,.jp2,.zip,.geojson,.json,.csv,.mbtiles,.pmtiles,.kml,.kmz,.png,.jpg,.jpeg,.webp" onChange={(event) => {
            const file = event.target.files?.[0];
            if (file) inspect(file);
          }} />
          ＋ فحص ملف
        </label>
      </article>

      {inspection && (
        <article className="panel">
          <h3>نتيجة فحص الملف</h3>
          <div className="report-table">
            {Object.entries(inspection.file).map(([key, value]) => (
              <div key={key}><strong>{key}</strong><span>{Array.isArray(value) ? value.join(", ") : String(value)}</span></div>
            ))}
          </div>
        </article>
      )}

      {report && (
        <article className="panel">
          <h3>ملخص التقرير</h3>
          <div className="report-table">
            {Object.entries(report).slice(0, 24).map(([key, value]) => (
              <div key={key}><strong>{key}</strong><span>{typeof value === "object" ? JSON.stringify(value) : String(value)}</span></div>
            ))}
          </div>
        </article>
      )}

      <article className="panel warning-panel">
        <h3>قاعدة الصدق العلمي</h3>
        <p>بوح التضاريس منصة تحليل تضاريس وطبقات سطحية وسلامة ميدانية. النتائج احتمالية وتحتاج تحقق ميداني. النظام لا يثبت وجود ذهب أو دفائن أو أهداف تحت الأرض.</p>
      </article>
    </section>
  );
}
