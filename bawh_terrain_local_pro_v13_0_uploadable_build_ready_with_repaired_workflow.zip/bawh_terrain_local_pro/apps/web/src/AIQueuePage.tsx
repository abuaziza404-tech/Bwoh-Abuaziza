import React, { useEffect, useState } from "react";
import { AIAnalysisJob, createDefaultRegionalAIJobs, listAIAnalysisJobs, markAIJobReviewed } from "./api";

export default function AIQueuePage({ onMessage }: { onMessage: (message: string) => void }) {
  const [jobs, setJobs] = useState<AIAnalysisJob[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    try {
      const response = await listAIAnalysisJobs();
      setJobs(response);
      onMessage(`تم تحميل ${response.length} مهمة AI.`);
    } catch {
      onMessage("لا يمكن تحميل طابور AI الآن.");
    } finally {
      setLoading(false);
    }
  }

  async function createDefaults() {
    setLoading(true);
    try {
      await createDefaultRegionalAIJobs();
      await load();
      onMessage("تم توليد مهام AI افتراضية للحزم.");
    } catch {
      onMessage("فشل توليد مهام AI.");
    } finally {
      setLoading(false);
    }
  }

  async function markReviewed(id: number) {
    try {
      await markAIJobReviewed(id);
      await load();
      onMessage("تم تعليم المهمة كمراجعة.");
    } catch {
      onMessage("فشل تحديث المهمة.");
    }
  }

  return (
    <section className="screen">
      <article className="hero-card compact">
        <span className="eyebrow">AI Analysis Queue</span>
        <h2>طابور منظم للمهام التي تحتاج نموذجًا لاحقًا</h2>
        <p>لا نجبر النظام على تحليل غير مؤكد. كل حزمة قابلة للتحليل الآن أو لاحقًا تدخل في مسار واضح.</p>
        <div className="action-row">
          <button className="primary" onClick={createDefaults}>{loading ? "جاري..." : "توليد مهام افتراضية"}</button>
          <button className="secondary" onClick={load}>تحديث</button>
        </div>
      </article>

      <section className="ai-list">
        {jobs.length === 0 && <article className="panel"><p>لا توجد مهام. اضغط توليد مهام افتراضية.</p></article>}
        {jobs.map((job) => (
          <article key={job.id} className={`ai-card priority-${job.priority}`}>
            <div className="ai-card-head">
              <div>
                <h3>{taskLabel(job.task_type)}</h3>
                <p>{roleLabel(job.dataset_role)} · {job.dataset_name}</p>
              </div>
              <span>{statusLabel(job.status)}</span>
            </div>
            <div className="ai-meta">
              <small>الأولوية: {priorityLabel(job.priority)}</small>
              <small>النموذج: {job.model_name}</small>
              <small>المراجعة: {job.human_review_status === "reviewed" ? "تمت" : "لم تتم"}</small>
            </div>
            {job.notes_ar && <p className="ai-note">{job.notes_ar}</p>}
            <button className="secondary" onClick={() => markReviewed(job.id)}>تعليم كمراجَع</button>
          </article>
        ))}
      </section>
    </section>
  );
}

function taskLabel(task: string) {
  const labels: Record<string, string> = {
    image_pattern_review: "مراجعة أنماط الصور",
    spectral_anomaly_review: "تحليل شذوذ طيفي",
    local_register_review: "مراجعة سجل محلي",
    cross_dataset_comparison: "مقارنة بين الحزم",
    regional_corridor_review: "مراجعة الممر الإقليمي",
    report_generation: "توليد تقرير"
  };
  return labels[task] ?? task;
}

function roleLabel(role: string) {
  const labels: Record<string, string> = {
    regional_south: "النطاق الجنوبي",
    regional_center: "نطاق الوسط",
    regional_north: "النطاق الشمالي",
    port_partial: "Port الجزئي",
    local_target_west: "الهدف المحلي الغربي",
    local_target_east: "الهدف المحلي الشرقي",
    abuziza_local_app: "سجل أبو عزيزة المحلي"
  };
  return labels[role] ?? role;
}

function statusLabel(status: string) {
  return status === "queued" ? "في الطابور" : status === "completed" ? "مكتملة" : status;
}

function priorityLabel(priority: string) {
  return priority === "high" ? "مرتفعة" : priority === "critical" ? "حرجة" : priority === "low" ? "منخفضة" : "عادية";
}
