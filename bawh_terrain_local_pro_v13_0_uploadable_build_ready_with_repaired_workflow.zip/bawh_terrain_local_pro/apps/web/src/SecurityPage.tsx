import React from "react";
import { AppIdentity } from "./api";
import AdminAuthPanel from "./AdminAuthPanel";

export default function SecurityPage({ identity, onMessage }: { identity: AppIdentity | null; onMessage: (message: string) => void }) {
  const controls = [
    "تشغيل Offline-first وعدم تعطيل النظام عند انقطاع الإنترنت",
    "فك ضغط ZIP آمن ضد Path Traversal",
    "تقييد أنواع الملفات والحجم",
    "عدم تنفيذ أي ملف مرفوع",
    "تخزين Cache محلي للطقس والمصادر الخارجية",
    "Security Headers من API",
    "فصل المزايا المحلية عن المتصلة بالإنترنت",
    "توثيق SECURITY.md داخل المشروع"
  ];

  return (
    <section className="screen">
      <article className="hero-card compact">
        <span className="eyebrow">Security Center</span>
        <h2>توثيق الأمان والتشغيل المحلي</h2>
        <p>{identity?.security_profile ?? "Offline-first, safe uploads, local cache, audit-ready."}</p>
      </article>

      <article className="developer-secure-card">
        <span>المطور المعتمد</span>
        <strong>{identity?.developer_name_ar ?? "أحمد أبوعزيزة الرشيدي"}</strong>
        <p>{identity?.disclaimer_ar ?? "النظام لتحليل التضاريس والطقس والطبقات السطحية."}</p>
      </article>

      <section className="security-grid">
        {controls.map((control) => (
          <div key={control} className="security-control">
            <b>✓</b>
            <span>{control}</span>
          </div>
        ))}
      </section>

      <AdminAuthPanel onMessage={onMessage} />

      <article className="panel warning-panel">
        <h3>حدود التحليل</h3>
        <p>النظام يقدم قراءة سطحية/طيفية/طقسية وتنظيم بيانات. لا يعتمد أي ادعاء غير قابل للتحقق ولا يثبت وجود أهداف تحت الأرض.</p>
      </article>
    </section>
  );
}
