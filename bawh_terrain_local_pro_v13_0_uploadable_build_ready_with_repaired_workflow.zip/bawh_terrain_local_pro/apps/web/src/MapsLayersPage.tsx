import React, { useEffect, useState } from "react";
import { BaseLayerCatalog, getBaseLayerCatalog } from "./api";

export default function MapsLayersPage({ onMessage }: { onMessage: (message: string) => void }) {
  const [catalog, setCatalog] = useState<BaseLayerCatalog | null>(null);
  const [activeGroup, setActiveGroup] = useState("satellite");

  useEffect(() => {
    load();
  }, []);

  async function load() {
    try {
      const response = await getBaseLayerCatalog();
      setCatalog(response);
      onMessage("تم تحميل كتالوج الخرائط والطبقات الأساسية.");
    } catch {
      onMessage("تعذر تحميل كتالوج الخرائط؛ ستبقى طبقات الرادار المحلية متاحة.");
    }
  }

  const groups = catalog?.groups ?? [];
  const active = groups.find((group) => group.id === activeGroup) ?? groups[0];

  return (
    <section className="screen">
      <article className="hero-card compact">
        <span className="eyebrow">قسم الخرائط والطبقات الأساسية</span>
        <h2>إدارة الخرائط الفضائية، الشوارع، الحزم المحلية، وطبقات التحليل</h2>
        <p>هذا القسم يفصل طبقات الخرائط عن الرادار لتسهيل التشغيل الميداني، وحفظ المناطق أثناء الإنترنت للعمل عند الانقطاع.</p>
        <button className="primary" type="button" onClick={load}>تحديث الكتالوج</button>
      </article>

      <div className="map-layer-tabs">
        {groups.map((group) => (
          <button
            key={group.id}
            className={active?.id === group.id ? "active" : ""}
            type="button"
            onClick={() => setActiveGroup(group.id)}
          >
            {group.label_ar}
          </button>
        ))}
      </div>

      <section className="base-layer-grid">
        {(active?.layers ?? []).map((layer) => (
          <article key={layer.id} className="base-layer-card">
            <div className="base-layer-icon">{layerIcon(layer.type)}</div>
            <div>
              <h3>{layer.label_ar}</h3>
              <p>{layerDescription(layer.id, layer.type)}</p>
              <div className="base-layer-meta">
                <span>{layer.type}</span>
                <span>{layer.online_required ? "يتطلب إنترنت" : "محلي"}</span>
                {layer.offline_cache && <span>يدعم Offline</span>}
              </div>
            </div>
          </article>
        ))}
      </section>

      <article className="panel">
        <h3>قواعد تشغيل الطبقات</h3>
        <ul className="clean-list">
          <li>Esri Satellite وOSM يتم حفظهما عبر Cache عند توفر الإنترنت.</li>
          <li>MBTiles وPMTiles الأفضل للمناطق الكبيرة والعمل الطويل بدون إنترنت.</li>
          <li>طبقات التحليل مثل NDVI/Slope تعمل محليًا بعد توليدها من المشروع.</li>
          <li>الطوارئ تظهر في قسم مستقل وترتبط بالخرائط عند توفر المصادر.</li>
        </ul>
      </article>
    </section>
  );
}

function layerIcon(type: string) {
  if (type.includes("raster")) return "🛰️";
  if (type.includes("local")) return "📦";
  if (type.includes("spectral")) return "🌈";
  if (type.includes("project")) return "🗺️";
  return "▧";
}

function layerDescription(id: string, type: string) {
  const descriptions: Record<string, string> = {
    esri_satellite: "صور فضائية عالية الوضوح، مناسبة للاستطلاع والمراجعة البصرية.",
    esri_hybrid_reference: "أسماء وحدود فوق الصور الفضائية لقراءة المواقع بسرعة.",
    osm_streets: "شوارع ومسارات ومناطق مأهولة من OpenStreetMap.",
    mbtiles: "حزمة خرائط محلية مستقرة للميدان والمناطق الكبيرة.",
    pmtiles: "حزمة خرائط حديثة ملف واحد قابلة للعرض المباشر عند التوافق.",
    hillshade: "تظليل تضاريس يوضح البروز والانحدارات.",
    slope: "ميل السطح لتقييم صعوبة الحركة والسلامة.",
    flow: "اتجاهات الجريان ومناطق تجمع المياه.",
    ndvi: "مؤشر نباتي سطحي.",
    ndwi: "مؤشر رطوبة/مياه سطحي.",
    bsi: "مؤشر انكشاف التربة."
  };

  return descriptions[id] ?? `طبقة من نوع ${type}.`;
}
