import React, { useState } from "react";
import { bootstrapAdmin, login } from "./api";

export default function AdminAuthPanel({ onMessage }: { onMessage: (message: string) => void }) {
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("");
  const [tokenPreview, setTokenPreview] = useState(localStorage.getItem("bawh.api.token") ?? "");

  async function createAdmin() {
    try {
      const response = await bootstrapAdmin(username, password);
      localStorage.setItem("bawh.api.token", response.access_token);
      setTokenPreview(response.access_token);
      onMessage("تم إنشاء مدير API وحفظ الرمز محليًا.");
    } catch (error) {
      onMessage(error instanceof Error ? error.message : "فشل إنشاء المدير.");
    }
  }

  async function signIn() {
    try {
      const response = await login(username, password);
      localStorage.setItem("bawh.api.token", response.access_token);
      setTokenPreview(response.access_token);
      onMessage("تم تسجيل الدخول إلى API.");
    } catch (error) {
      onMessage(error instanceof Error ? error.message : "فشل تسجيل الدخول.");
    }
  }

  function clearToken() {
    localStorage.removeItem("bawh.api.token");
    setTokenPreview("");
    onMessage("تم حذف رمز API المحلي.");
  }

  return (
    <article className="panel admin-auth-panel">
      <h3>JWT/RBAC API</h3>
      <p>نظام مستخدمين للخادم بجانب قفل PIN المحلي. أول مرة استخدم إنشاء مدير، وبعدها استخدم تسجيل الدخول.</p>

      <input
        value={username}
        onChange={(event) => setUsername(event.target.value)}
        placeholder="اسم المستخدم"
      />

      <input
        value={password}
        type="password"
        onChange={(event) => setPassword(event.target.value)}
        placeholder="كلمة المرور"
      />

      <div className="action-row">
        <button className="primary" type="button" onClick={createAdmin}>إنشاء مدير</button>
        <button className="secondary" type="button" onClick={signIn}>دخول</button>
      </div>

      {tokenPreview && (
        <div className="token-preview">
          <span>Token محفوظ</span>
          <code>{tokenPreview.slice(0, 28)}...</code>
          <button type="button" onClick={clearToken}>حذف</button>
        </div>
      )}
    </article>
  );
}
