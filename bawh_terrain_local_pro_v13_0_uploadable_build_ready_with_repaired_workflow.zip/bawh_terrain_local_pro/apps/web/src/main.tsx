import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import LocalAuthGate from "./LocalAuthGate";
import "./style.css";
if ("serviceWorker" in navigator) window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(() => undefined));
ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(<React.StrictMode><LocalAuthGate onMessage={() => undefined}><App /></LocalAuthGate></React.StrictMode>);
