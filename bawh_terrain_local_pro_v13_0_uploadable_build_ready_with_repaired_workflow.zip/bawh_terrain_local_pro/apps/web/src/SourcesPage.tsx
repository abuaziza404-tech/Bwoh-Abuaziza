import React, { useEffect, useState } from "react";
import { SourceStatus, getSourceStatus, isNetworkError } from "./api";

export default function SourcesPage({ onMessage }: { onMessage: (message: string) => void }) {
  const [status, setStatus] = useState<SourceStatus | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    try {
      const response = await getSourceStatus();
      setStatus(response);
      onMessage("تم تحديث حالة مصادر الأقمار والطقس.");
    } catch (error) {
      onMessage(isNetworkError(error) ? "API غير متصل، ستبقى المصادر المحلية متاحة." : "فشل جلب حالة المصادر.");
    } finally {
      setLoading(false);
    }
  }

  const grouped = groupBy(status?.sources ?? [], (source) => source.category);

  return (
    <section className="screen">
      <article className="hero-card compact">
        <span className="eyebrow">لوحة المصادر</span>
        <h2>حالة الأقمار، الطقس، الطبقات، والبيانات المحلية</h2>
        <p>المصادر المحلية تعمل دائمًا. المصادر المتصلة تتفعل عند توفر الإنترنت والمفاتيح المطلوبة.</p>
        <button className="primary" onClick={load}>{loading ? "جاري..." : "فحص المصادر"}</button>
      </article>

      {Object.entries(grouped).map(([category, sources]) => (
        <article key={category} className="panel">
          <div className="panel-head">
            <h3>{categoryLabel(category)}</h3>
            <span>{sources.length}</span>
          </div>

          <div className="source-grid">
            {sources.map((source) => (
              <div key={source.id} className={source.enabled ? "source-card enabled" : "source-card"}>
                <div className="source-top">
                  <strong>{source.label_ar}</strong>
                  <span>{modeLabel(source.mode)}</span>
                </div>
                <p>{source.message_ar}</p>
                <div className="source-foot">
                  <small>{source.configured ? "معدّ" : "غير معدّ"}</small>
                  <small>{source.enabled ? "مفعل" : "محلي/مؤجل"}</small>
                </div>
              </div>
            ))}
          </div>
        </article>
      ))}

      <article className="panel note-panel">
        <h3>قواعد التشغيل</h3>
        <p>OpenTopography وSentinel Hub وSoilGrids وOSM تحتاج إنترنت. الرادار، مكتبة النطاقات، طابور AI، والنتائج المحفوظة تعمل بدون إنترنت.</p>
      </article>
    </section>
  );
}

function groupBy<T>(items: T[], keyFn: (item: T) => string) {
  return items.reduce<Record<string, T[]>>((acc, item) => {
    const key = keyFn(item);
    acc[key] = acc[key] ?? [];
    acc[key].push(item);
    return acc;
  }, {});
}

function categoryLabel(category: string) {
  const labels: Record<string, string> = {
    satellite: "الأقمار والارتفاعات",
    weather: "الطقس والسلامة",
    local: "المحلي والملفات",
    ai: "الذكاء الاصطناعي",
    maps: "الخرائط والسياق"
  };
  return labels[category] ?? category;
}

function modeLabel(mode: string) {
  if (mode === "online") return "متصل";
  if (mode === "hybrid") return "هجين";
  return "محلي";
}
