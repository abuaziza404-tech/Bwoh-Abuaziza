import React, { useEffect, useMemo, useState } from "react";
import MapLibreRadar from "./MapLibreRadar";
import OfflineMapManager from "./OfflineMapManager";
import BouhLightweightRadarPanel from "./bouh/BouhLightweightRadarPanel";
import BouhLiveGroundScoreMeter from "./bouh/BouhLiveGroundScoreMeter";
import "./bouh/bouh_panel.css";
import "./bouh/bouh_live_meter.css";
import { getNativePosition } from "./native";
import {
  AIAnalysisJob,
  BandRole,
  Project,
  ProjectLayer,
  RadarLibraryItem,
  createDefaultRegionalAIJobs,
  getProjectLayers,
  getRadarLibrary,
  getRegionalCorridor,
  listAIAnalysisJobs,
  rerunProject,
  startRadarScan,
  getProjectReportHtmlUrl,
  uploadProjectFile,
  uploadRadarDataset
} from "./api";

const bandRoles: BandRole[] = ["blue", "green", "red", "nir", "swir"];
const layerOrder = ["hillshade", "slope", "flow", "ndvi", "ndwi", "bsi", "ndmi"] as const;

export default function RadarPage({
  project,
  lat,
  lng,
  onCoords,
  onMessage
}: {
  project: Project | null;
  lat: number;
  lng: number;
  onCoords: (lat: number, lng: number) => void;
  onMessage: (message: string) => void;
}) {
  const [radius, setRadius] = useState(300);
  const [resolutionMode, setResolutionMode] = useState<"standard" | "high" | "ultra">("high");
  const [selectedBand, setSelectedBand] = useState<BandRole>("red");
  const [library, setLibrary] = useState<RadarLibraryItem[]>([]);
  const [layers, setLayers] = useState<ProjectLayer[]>([]);
  const [jobs, setJobs] = useState<AIAnalysisJob[]>([]);
  const [selectedRole, setSelectedRole] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [layerOpacity, setLayerOpacity] = useState<Record<string, number>>(() => Object.fromEntries(layerOrder.map((name) => [name, name === "hillshade" ? 45 : 62])));
  const [enabledLayers, setEnabledLayers] = useState<Record<string, boolean>>(() => Object.fromEntries(layerOrder.map((name) => [name, true])));
  const [liveScoreRefreshKey, setLiveScoreRefreshKey] = useState(0);

  const selectedItem = useMemo(() => library.find((item) => item.role === selectedRole) ?? library[0], [library, selectedRole]);
  const availableLayerCount = layers.filter((layer) => layer.available).length;

  useEffect(() => {
    refreshAll();
  }, [project?.id]);

  async function refreshAll() {
    await Promise.allSettled([loadLibrary(), loadLayers(), loadJobs()]);
  }

  async function loadLibrary() {
    try {
      const response = await getRadarLibrary();
      setLibrary(response.items);
      if (!selectedRole && response.items.length > 0) {
        setSelectedRole(response.items[0].role);
      }
    } catch {
      onMessage("لم يتم العثور على مكتبة رادار محلية بعد.");
    }
  }

  async function loadLayers() {
    if (!project) {
      setLayers([]);
      return;
    }

    try {
      setLayers(await getProjectLayers(project.id));
    } catch {
      setLayers([]);
    }
  }

  async function loadJobs() {
    try {
      setJobs(await listAIAnalysisJobs());
    } catch {
      setJobs([]);
    }
  }

  async function runRadar() {
    if (!project) {
      onMessage("أنشئ مشروعًا أولًا من الصفحة الرئيسية.");
      return;
    }

    setBusy(true);

    try {
      await startRadarScan({
        project_id: project.id,
        center_lat: lat,
        center_lng: lng,
        radius_m: radius,
        resolution_mode: resolutionMode,
        enabled_layers: layerOrder.filter((name) => enabledLayers[name]) as unknown as string[]
      });
      onMessage("تم تشغيل الرادار وإرسال المهمة إلى محرك التحليل.");
      window.setTimeout(() => {
        loadLayers();
      }, 2200);
    } catch (error) {
      onMessage(error instanceof Error ? error.message : "فشل تشغيل الرادار.");
    } finally {
      setBusy(false);
    }
  }

  async function rerunAnalysis() {
    if (!project) {
      onMessage("لا يوجد مشروع نشط.");
      return;
    }

    setBusy(true);

    try {
      await rerunProject(project.id);
      onMessage("تمت إعادة التحليل مع البيانات الحالية.");
      window.setTimeout(() => {
        loadLayers();
      }, 2200);
    } catch (error) {
      onMessage(error instanceof Error ? error.message : "فشلت إعادة التحليل.");
    } finally {
      setBusy(false);
    }
  }

  async function uploadZip(file: File) {
    if (!project) {
      onMessage("أنشئ مشروعًا أولًا قبل رفع حزمة ZIP.");
      return;
    }

    setBusy(true);

    try {
      await uploadRadarDataset(project.id, file);
      await loadLibrary();
      onMessage("تم رفع وفهرسة حزمة ZIP وربطها بالرادار.");
    } catch (error) {
      onMessage(error instanceof Error ? error.message : "فشل رفع حزمة ZIP.");
    } finally {
      setBusy(false);
    }
  }

  async function uploadBand(file: File) {
    if (!project) {
      onMessage("أنشئ مشروعًا أولًا قبل رفع الباند.");
      return;
    }

    setBusy(true);

    try {
      await uploadProjectFile(project.id, file, selectedBand);
      onMessage(`تم رفع ${file.name} كباند ${selectedBand}.`);
    } catch (error) {
      onMessage(error instanceof Error ? error.message : "فشل رفع الباند.");
    } finally {
      setBusy(false);
    }
  }

  async function showCorridor() {
    try {
      const corridor = await getRegionalCorridor();
      const message = typeof corridor.analysis?.interpretation_ar === "string"
        ? corridor.analysis.interpretation_ar
        : `تم تحميل ${corridor.segments.length} قطاعات من الممر الإقليمي.`;
      onMessage(message);
    } catch (error) {
      onMessage(error instanceof Error ? error.message : "فشل تحميل الممر الإقليمي.");
    }
  }

  async function createAIJobs() {
    setBusy(true);

    try {
      await createDefaultRegionalAIJobs();
      await loadJobs();
      onMessage("تم توليد مهام AI افتراضية لكل الحزم.");
    } catch (error) {
      onMessage(error instanceof Error ? error.message : "فشل توليد مهام AI.");
    } finally {
      setBusy(false);
    }
  }


  function openReport() {
    if (!project) {
      onMessage("أنشئ مشروعًا أولًا لتوليد التقرير.");
      return;
    }
    window.open(getProjectReportHtmlUrl(project.id), "_blank", "noopener,noreferrer");
  }

  async function useNativeGps() {
    const position = await getNativePosition();

    if (!position) {
      onMessage("لم يتم الحصول على GPS من الجهاز.");
      return;
    }

    onCoords(position.lat, position.lng);
    onMessage("تم تحديث موقع الرادار من GPS الجهاز.");
  }

  function nudgeTarget(direction: "north" | "south" | "east" | "west") {
    const delta = 0.01;
    const nextLat = direction === "north" ? lat + delta : direction === "south" ? lat - delta : lat;
    const nextLng = direction === "east" ? lng + delta : direction === "west" ? lng - delta : lng;
    onCoords(nextLat, nextLng);
    onMessage("تم تعديل مركز الرادار.");
  }

  return (
    <section className="screen radar-layout">
      <article className="radar-console">
        <div className="radar-toolbar">
          <div>
            <span className="eyebrow">رادار تحليل ميداني</span>
            <h2>الموقع والنطاق والطبقات</h2>
          </div>
          <strong>{project ? `#${project.id}` : "لا يوجد مشروع"}</strong>
        </div>

        <MapLibreRadar
          projectId={project?.id ?? null}
          lat={lat}
          lng={lng}
          radius={radius}
          layers={layers}
          enabledLayers={enabledLayers}
          layerOpacity={layerOpacity}
          selectedItem={selectedItem}
          onCoords={onCoords}
          onMessage={onMessage}
        />

        <BouhLightweightRadarPanel
          onMessage={onMessage}
          onFlyTo={(nextLat, nextLng, label) => {
            onCoords(nextLat, nextLng);
            onMessage(`تم توجيه الرادار إلى ${label} للفحص الميداني.`);
          }}
        />

        <div className="pad-controls" aria-label="تعديل مركز الرادار">
          <button onClick={() => nudgeTarget("north")}>شمال</button>
          <button onClick={() => nudgeTarget("west")}>غرب</button>
          <button onClick={() => nudgeTarget("east")}>شرق</button>
          <button onClick={() => nudgeTarget("south")}>جنوب</button>
        </div>

        <div className="range-box">
          <div>
            <span>نطاق المسح</span>
            <strong>{radius} متر</strong>
          </div>
          <input type="range" min={50} max={5000} step={50} value={radius} onChange={(event) => setRadius(Number(event.target.value))} />
        </div>

        <div className="segmented">
          {(["standard", "high", "ultra"] as const).map((mode) => (
            <button
              key={mode}
              className={resolutionMode === mode ? "active" : ""}
              onClick={() => setResolutionMode(mode)}
              type="button"
            >
              {mode === "standard" ? "قياسي" : mode === "high" ? "عالٍ" : "فائق"}
            </button>
          ))}
        </div>

        <div className="action-row">
          <button className="primary" onClick={runRadar} disabled={busy || !project}>
            {busy ? "جاري..." : "بدء المسح"}
          </button>
          <button className="secondary" onClick={rerunAnalysis} disabled={busy || !project}>
            إعادة التحليل
          </button>
          <button className="secondary" onClick={useNativeGps}>
            GPS الجهاز
          </button>
          <button className="secondary" onClick={openReport} disabled={!project}>
            توليد تقرير
          </button>
        </div>
      </article>

      <article className="panel layer-panel">
        <div className="panel-head">
          <h3>طبقات التحليل</h3>
          <span>{availableLayerCount}/{layers.length || layerOrder.length}</span>
        </div>
        <div className="layer-grid layer-control-grid">
          {layerOrder.map((name) => {
            const layer = layers.find((item) => item.name === name);
            const ready = Boolean(layer?.available);
            return (
              <div key={name} className={ready ? "layer-chip ready" : "layer-chip"}>
                <b>{layerIcon(name)}</b>
                <span>{name.toUpperCase()}</span>
                <small>{ready ? "جاهزة" : "تحتاج تحليل"}</small>
                <label className="layer-toggle">
                  <input
                    type="checkbox"
                    checked={enabledLayers[name]}
                    onChange={(event) => setEnabledLayers((current) => ({ ...current, [name]: event.target.checked }))}
                  />
                  إظهار
                </label>
                <input
                  className="opacity-slider"
                  type="range"
                  min={10}
                  max={100}
                  value={layerOpacity[name]}
                  onChange={(event) => setLayerOpacity((current) => ({ ...current, [name]: Number(event.target.value) }))}
                />
                <small>Opacity {layerOpacity[name]}%</small>
              </div>
            );
          })}
        </div>
        <div className="layer-legend">
          <span><i className="legend-green" /> NDVI/NDMI أعلى = نبات/رطوبة نسبية</span>
          <span><i className="legend-blue" /> NDWI أعلى = أثر رطوبة/مياه سطحية</span>
          <span><i className="legend-brown" /> BSI أعلى = انكشاف تربة</span>
          <span><i className="legend-gray" /> Slope/Hillshade = تضاريس</span>
        </div>
      </article>

      <article className="panel upload-panel">
        <div className="panel-head">
          <h3>رفع البيانات</h3>
          <span>ZIP / Bands</span>
        </div>

        <div className="band-selector">
          {bandRoles.map((role) => (
            <button
              key={role}
              type="button"
              className={selectedBand === role ? "active" : ""}
              onClick={() => setSelectedBand(role)}
            >
              {role}
            </button>
          ))}
        </div>

        <div className="upload-grid">
          <label className="upload">
            <input type="file" accept=".zip" onChange={(event) => {
              const file = event.target.files?.[0];
              if (file) uploadZip(file);
            }} />
            ＋ رفع حزمة ZIP
          </label>

          <label className="upload">
            <input type="file" accept=".tif,.tiff,.jp2,.png,.jpg,.jpeg,.webp,.geojson,.json" onChange={(event) => {
              const file = event.target.files?.[0];
              if (file) uploadBand(file);
            }} />
            ＋ رفع باند/ملف
          </label>
        </div>
      </article>

      <article className="panel library-panel">
        <div className="panel-head">
          <h3>مكتبة الرادار</h3>
          <button onClick={loadLibrary}>تحديث</button>
        </div>

        <div className="library-tabs">
          {library.map((item) => (
            <button
              key={item.role}
              type="button"
              className={selectedItem?.role === item.role ? "active" : ""}
              onClick={() => setSelectedRole(item.role)}
            >
              {item.label_ar}
            </button>
          ))}
        </div>

        {selectedItem && (
          <div className="library-detail">
            <h4>{selectedItem.label_ar}</h4>
            <p>{selectedItem.recommendation_ar}</p>
            <div className="mini-metrics">
              <SmallMetric label="NDVI" value={selectedItem.ndvi_mean} />
              <SmallMetric label="NDWI" value={selectedItem.ndwi_mean} />
              <SmallMetric label="BSI" value={selectedItem.bsi_mean} />
              <SmallMetric label="NDMI" value={selectedItem.ndmi_mean} />
            </div>
            <div className="detail-row">
              <span>الباندات: {selectedItem.band_count}</span>
              <span>{selectedItem.complete_core ? "مكتمل" : "جزئي"}</span>
              <span>{statusLabel(selectedItem.analysis_status)}</span>
            </div>
          </div>
        )}

        <div className="action-row">
          <button className="secondary" onClick={showCorridor}>قراءة الممر الإقليمي</button>
          <button className="secondary" onClick={createAIJobs}>توليد مهام AI</button>
        </div>
      </article>


      <BouhLiveGroundScoreMeter
        key={`${lat}-${lng}-${radius}-${liveScoreRefreshKey}`}
        lat={lat}
        lng={lng}
        radius={radius}
      />

      <OfflineMapManager
        lat={lat}
        lng={lng}
        radius={radius}
        onMessage={onMessage}
      />

      <article className="panel ai-compact">
        <div className="panel-head">
          <h3>طابور AI</h3>
          <span>{jobs.length} مهمة</span>
        </div>
        <div className="job-strip">
          {jobs.slice(0, 5).map((job) => (
            <div key={job.id} className="job-pill">
              <b>{job.dataset_role}</b>
              <small>{job.task_type} · {job.status}</small>
            </div>
          ))}
          {jobs.length === 0 && <p>لا توجد مهام بعد. استخدم زر توليد مهام AI.</p>}
        </div>
      </article>
    </section>
  );
}

function SmallMetric({ label, value }: { label: string; value: number | null }) {
  return (
    <div className="small-metric">
      <span>{label}</span>
      <strong>{typeof value === "number" ? value.toFixed(3) : "—"}</strong>
    </div>
  );
}

function statusLabel(status: string) {
  if (status === "analysis_ready") return "جاهز للتحليل";
  if (status === "partial_context_only") return "سياق جزئي";
  if (status === "register_import_only") return "سجل محلي";
  return "حفظ خام";
}

function layerIcon(layer: string) {
  const icons: Record<string, string> = {
    hillshade: "🌘",
    slope: "📐",
    flow: "〰️",
    ndvi: "🌿",
    ndwi: "💧",
    bsi: "🟫",
    ndmi: "🌫️"
  };
  return icons[layer] ?? "▧";
}
