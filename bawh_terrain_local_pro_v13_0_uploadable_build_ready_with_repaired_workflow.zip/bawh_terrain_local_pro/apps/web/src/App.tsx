import React, { useEffect, useMemo, useState } from "react";
import {
  AppIdentity,
  Project,
  SystemOverview,
  createProject,
  getIdentity,
  getSystemOverview,
  isNetworkError
} from "./api";
import RadarPage from "./RadarPage";
import SafetyPage from "./SafetyPage";
import SourcesPage from "./SourcesPage";
import WorkflowPage from "./WorkflowPage";
import AIQueuePage from "./AIQueuePage";
import SecurityPage from "./SecurityPage";
import MapsLayersPage from "./MapsLayersPage";
import EmergencyPage from "./EmergencyPage";
import LibraryPage from "./LibraryPage";
import ReportPage from "./ReportPage";
import PWAInstallPrompt from "./PWAInstallPrompt";

type Screen = "dashboard" | "radar" | "library" | "safety" | "reports" | "sources" | "security";

const navItems: Array<{ id: Screen; label: string; icon: string }> = [
  { id: "dashboard", label: "الرئيسية", icon: "⌂" },
  { id: "radar", label: "الرادار", icon: "⌖" },
  { id: "library", label: "المكتبة", icon: "📚" },
  { id: "safety", label: "السلامة", icon: "🛡️" },
  { id: "reports", label: "التقارير", icon: "📄" },
  { id: "sources", label: "المصادر", icon: "🛰️" },
  { id: "security", label: "الأمان", icon: "🔐" }
];

export default function App() {
  const [screen, setScreen] = useState<Screen>("dashboard");
  const [lat, setLat] = useState(24.7136);
  const [lng, setLng] = useState(46.6753);
  const [project, setProject] = useState<Project | null>(null);
  const [message, setMessage] = useState("جاهز للعمل المحلي");
  const [identity, setIdentity] = useState<AppIdentity | null>(null);
  const [overview, setOverview] = useState<SystemOverview | null>(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isCreatingProject, setIsCreatingProject] = useState(false);

  useEffect(() => {
    refreshIdentityAndOverview();

    const online = () => {
      setIsOnline(true);
      setMessage("تم الاتصال بالإنترنت. الميزات المتصلة جاهزة للتحديث.");
    };

    const offline = () => {
      setIsOnline(false);
      setMessage("وضع بدون إنترنت: ستعمل البيانات المحلية وآخر Cache محفوظ.");
    };

    window.addEventListener("online", online);
    window.addEventListener("offline", offline);

    return () => {
      window.removeEventListener("online", online);
      window.removeEventListener("offline", offline);
    };
  }, []);

  async function refreshIdentityAndOverview() {
    try {
      const [id, sys] = await Promise.all([getIdentity(), getSystemOverview()]);
      setIdentity(id);
      setOverview(sys);
    } catch (error) {
      if (isNetworkError(error)) {
        setMessage("الواجهة تعمل محليًا، لكن API غير متصل حاليًا.");
      } else {
        setMessage("تعذر تحميل هوية النظام أو الملخص التشغيلي.");
      }
    }
  }

  async function ensureProject(): Promise<Project | null> {
    if (project) {
      return project;
    }

    setIsCreatingProject(true);

    try {
      const created = await createProject({
        name: `مشروع رادار ${new Date().toLocaleString("ar")}`,
        center_lat: lat,
        center_lng: lng,
        radius_m: 300,
        soil_type: "مختلطة",
        terrain_type: "هضاب"
      });

      setProject(created);
      setMessage(`تم إنشاء المشروع رقم ${created.id}.`);
      return created;
    } catch (error) {
      setMessage(error instanceof Error ? `فشل إنشاء المشروع: ${error.message}` : "فشل إنشاء المشروع.");
      return null;
    } finally {
      setIsCreatingProject(false);
    }
  }

  async function openRadar() {
    const created = await ensureProject();
    if (created) {
      setScreen("radar");
    }
  }

  const currentTitle = useMemo(() => {
    return navItems.find((item) => item.id === screen)?.label ?? "بوح التضاريس";
  }, [screen]);

  return (
    <main className="app-shell" dir="rtl">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark" />
          <div>
            <h1>{identity?.app_name ?? "بوح التضاريس"}</h1>
            <p>Local Pro · Offline-first · {currentTitle}</p>
          </div>
        </div>

        <div className="developer-badge">
          <span>المطور</span>
          <strong>{identity?.developer_name_ar ?? "أحمد أبوعزيزة الرشيدي"}</strong>
        </div>
      </header>

      <section className="command-strip">
        <div className={isOnline ? "net-pill online" : "net-pill offline"}>
          {isOnline ? "متصل" : "بدون إنترنت"}
        </div>
        <button type="button" onClick={refreshIdentityAndOverview}>تحديث النظام</button>
        <button type="button" onClick={openRadar} disabled={isCreatingProject}>
          {project ? `مشروع #${project.id}` : isCreatingProject ? "إنشاء..." : "إنشاء مشروع"}
        </button>
      </section>

      <div className="status-line">{message}</div>

      {screen === "dashboard" && (
        <>
          <div className="screen android-prompt-shell"><PWAInstallPrompt onMessage={setMessage} /></div>
          <Dashboard
          overview={overview}
          project={project}
          isOnline={isOnline}
          onOpenRadar={openRadar}
          onNavigate={setScreen}
        />
        </>
      )}

      {screen === "radar" && (
        <RadarPage
          project={project}
          lat={lat}
          lng={lng}
          onCoords={(nextLat, nextLng) => {
            setLat(nextLat);
            setLng(nextLng);
          }}
          onMessage={setMessage}
        />
      )}

      {screen === "safety" && (
        <SafetyPage
          lat={lat}
          lng={lng}
          projectId={project?.id ?? null}
          onMessage={setMessage}
        />
      )}

      {screen === "sources" && <SourcesPage onMessage={setMessage} />}
      {screen === "library" && <LibraryPage onMessage={setMessage} />}
      {screen === "reports" && <ReportPage project={project} onMessage={setMessage} />}
      {screen === "sources" && <MapsLayersPage onMessage={setMessage} />}
      {screen === "sources" && <EmergencyPage lat={lat} lng={lng} onMessage={setMessage} />}
      {screen === "security" && <SecurityPage identity={identity} onMessage={setMessage} />}

      <nav className="bottom-nav" aria-label="أقسام التطبيق">
        {navItems.map((item) => (
          <button
            key={item.id}
            type="button"
            className={screen === item.id ? "active" : ""}
            onClick={() => setScreen(item.id)}
          >
            <span>{item.icon}</span>
            <small>{item.label}</small>
          </button>
        ))}
      </nav>
    </main>
  );
}

function Dashboard({
  overview,
  project,
  isOnline,
  onOpenRadar,
  onNavigate
}: {
  overview: SystemOverview | null;
  project: Project | null;
  isOnline: boolean;
  onOpenRadar: () => void;
  onNavigate: (screen: Screen) => void;
}) {
  const counts = overview?.counts ?? {};

  return (
    <section className="screen dashboard-grid">
      <article className="hero-card hero-xl">
        <div>
          <span className="eyebrow">منظومة احترافية موحّدة</span>
          <h2>رادار تضاريس، مكتبة بيانات، سلامة ميدانية، ومصادر أقمار في واجهة منظمة واحدة.</h2>
          <p>
            التطبيق يعمل محليًا بدون إنترنت، ويُفعّل بيانات الطقس والأقمار والمصادر الخارجية تلقائيًا عند توفر الاتصال.
          </p>
        </div>

        <div className="hero-actions">
          <button className="primary" onClick={onOpenRadar}>فتح رادار التحليل</button>
          <button className="secondary" onClick={() => onNavigate("safety")}>السلامة والتنبؤات</button>
        </div>
      </article>

      <section className="metric-grid">
        <MetricCard label="المشاريع" value={counts.projects ?? 0} icon="▣" />
        <MetricCard label="حزم البيانات" value={counts.datasets ?? 0} icon="📦" />
        <MetricCard label="مهام AI" value={counts.ai_jobs ?? 0} icon="◈" />
        <MetricCard label="طبقات جاهزة" value={counts.layers ?? 0} icon="🗺️" />
      </section>

      <article className="operating-card">
        <h3>وضع التشغيل</h3>
        <div className="mode-grid">
          <ModeItem label="Offline-first" active />
          <ModeItem label="Cache محلي" active />
          <ModeItem label="مزايا الإنترنت" active={isOnline} />
          <ModeItem label="رفع آمن" active />
        </div>
      </article>

      <section className="feature-grid pro">
        <FeatureButton icon="⌖" title="الرادار" text="مسح، نطاق، طبقات، رفع باندات وZIP." onClick={onOpenRadar} />
        <FeatureButton icon="🗺️" title="الخرائط" text="خرائط أساسية، حزم محلية، وطبقات تحليل." onClick={() => onNavigate("sources")} />
        <FeatureButton icon="🚨" title="الطوارئ" text="Copernicus/FIRMS/Open‑Meteo ومحرك تنبؤ." onClick={() => onNavigate("safety")} />
        <FeatureButton icon="◈" title="التقارير" text="تقرير عربي وData Manager." onClick={() => onNavigate("reports")} />
        <FeatureButton icon="▣" title="المكتبة" text="South/Center/North والمقارنة الإقليمية." onClick={() => onNavigate("library")} />
        <FeatureButton icon="🔐" title="الأمان" text="سياسات حماية وتوثيق محلي." onClick={() => onNavigate("security")} />
      </section>

      {project && (
        <article className="panel success-panel">
          <h3>المشروع النشط</h3>
          <p>
            #{project.id} · {project.name} · {project.status} · {project.center_lat.toFixed(4)}, {project.center_lng.toFixed(4)}
          </p>
        </article>
      )}
    </section>
  );
}

function MetricCard({ label, value, icon }: { label: string; value: number; icon: string }) {
  return (
    <article className="metric-card">
      <span>{icon}</span>
      <strong>{value}</strong>
      <small>{label}</small>
    </article>
  );
}

function ModeItem({ label, active }: { label: string; active: boolean }) {
  return (
    <div className={active ? "mode-item active" : "mode-item"}>
      <i />
      <span>{label}</span>
    </div>
  );
}

function FeatureButton({
  icon,
  title,
  text,
  onClick
}: {
  icon: string;
  title: string;
  text: string;
  onClick: () => void;
}) {
  return (
    <button className="feature-action-card" type="button" onClick={onClick}>
      <b>{icon}</b>
      <strong>{title}</strong>
      <span>{text}</span>
    </button>
  );
}
