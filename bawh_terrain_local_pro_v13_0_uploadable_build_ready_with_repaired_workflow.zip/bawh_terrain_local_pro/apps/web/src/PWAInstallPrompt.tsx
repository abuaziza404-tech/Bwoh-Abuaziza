import React, { useEffect, useState } from "react";

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
};

export default function PWAInstallPrompt({ onMessage }: { onMessage: (message: string) => void }) {
  const [installEvent, setInstallEvent] = useState<BeforeInstallPromptEvent | null>(null);
  const [isStandalone, setIsStandalone] = useState(false);
  const [storageEstimate, setStorageEstimate] = useState<string>("");

  useEffect(() => {
    setIsStandalone(
      window.matchMedia("(display-mode: standalone)").matches
      || Boolean((window.navigator as Navigator & { standalone?: boolean }).standalone)
    );

    const handler = (event: Event) => {
      event.preventDefault();
      setInstallEvent(event as BeforeInstallPromptEvent);
      onMessage("يمكن تثبيت التطبيق على Android كتطبيق PWA.");
    };

    window.addEventListener("beforeinstallprompt", handler);

    if ("storage" in navigator && "estimate" in navigator.storage) {
      navigator.storage.estimate().then((estimate) => {
        const quota = estimate.quota ? formatBytes(estimate.quota) : "غير معروف";
        const usage = estimate.usage ? formatBytes(estimate.usage) : "0";
        setStorageEstimate(`${usage} / ${quota}`);
      }).catch(() => undefined);
    }

    return () => {
      window.removeEventListener("beforeinstallprompt", handler);
    };
  }, [onMessage]);

  async function install() {
    if (!installEvent) {
      onMessage("من Chrome على Android: افتح القائمة ⋮ ثم اختر تثبيت التطبيق أو Add to Home screen.");
      return;
    }

    await installEvent.prompt();
    const choice = await installEvent.userChoice;

    if (choice.outcome === "accepted") {
      setInstallEvent(null);
      onMessage("تم قبول تثبيت التطبيق.");
    } else {
      onMessage("تم إلغاء التثبيت.");
    }
  }

  async function requestPersistentStorage() {
    if (!("storage" in navigator) || !("persist" in navigator.storage)) {
      onMessage("المتصفح لا يدعم تثبيت التخزين الدائم.");
      return;
    }

    const granted = await navigator.storage.persist();

    if (granted) {
      onMessage("تم تفعيل التخزين الدائم لتقليل حذف خرائط Offline.");
    } else {
      onMessage("لم يمنح المتصفح التخزين الدائم. أبقِ مساحة كافية على الهاتف.");
    }
  }

  return (
    <article className="android-install-card">
      <div>
        <span>Android Field Mode</span>
        <h3>{isStandalone ? "مثبت كتطبيق" : "جاهز للتثبيت على Android"}</h3>
        <p>
          ثبّت التطبيق على الشاشة الرئيسية، ثم احفظ مناطق Esri Satellite أثناء الإنترنت للعمل عند انقطاعه.
        </p>
        {storageEstimate && <small>مساحة Cache: {storageEstimate}</small>}
      </div>

      <div className="android-install-actions">
        <button type="button" onClick={install}>
          تثبيت التطبيق
        </button>
        <button type="button" onClick={requestPersistentStorage}>
          تثبيت التخزين
        </button>
      </div>
    </article>
  );
}

function formatBytes(bytes: number) {
  if (bytes < 1024 * 1024) {
    return `${Math.round(bytes / 1024)} KB`;
  }

  if (bytes < 1024 * 1024 * 1024) {
    return `${Math.round(bytes / 1024 / 1024)} MB`;
  }

  return `${(bytes / 1024 / 1024 / 1024).toFixed(1)} GB`;
}
