const CACHE_NAME = "bawh-terrain-local-pro-v6-android";
const TILE_CACHE_NAME = "bawh-terrain-map-tiles-v6-android";
const CORE_ASSETS = [
  "/",
  "/index.html",
  "/manifest.webmanifest"
];

const TILE_HOST_PATTERNS = [
  "tile.openstreetmap.org",
  "services.arcgisonline.com"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(CORE_ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((key) => key !== CACHE_NAME && key !== TILE_CACHE_NAME)
          .map((key) => caches.delete(key))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const request = event.request;

  if (request.method !== "GET") {
    return;
  }

  const url = new URL(request.url);
  const isTileRequest = TILE_HOST_PATTERNS.some((host) => url.hostname.includes(host))
    || url.pathname.includes("/layers/")
    || url.pathname.endsWith(".png")
    || url.pathname.endsWith(".jpg")
    || url.pathname.endsWith(".jpeg")
    || url.pathname.endsWith(".webp");

  if (isTileRequest) {
    event.respondWith(cacheFirst(request, TILE_CACHE_NAME));
    return;
  }

  event.respondWith(networkFirst(request, CACHE_NAME));
});

async function cacheFirst(request, cacheName) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(request);

  if (cached) {
    return cached;
  }

  try {
    const response = await fetch(request);
    cache.put(request, response.clone()).catch(() => undefined);
    return response;
  } catch (error) {
    return cached || Response.error();
  }
}

async function networkFirst(request, cacheName) {
  const cache = await caches.open(cacheName);

  try {
    const response = await fetch(request);
    cache.put(request, response.clone()).catch(() => undefined);
    return response;
  } catch (error) {
    const cached = await cache.match(request);

    if (cached) {
      return cached;
    }

    if (request.mode === "navigate") {
      return cache.match("/index.html");
    }

    return Response.error();
  }
}


self.addEventListener("message", (event) => {
  if (!event.data || event.data.type !== "SKIP_WAITING") {
    return;
  }

  self.skipWaiting();
});
