#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
WEB_DIR="$ROOT_DIR/apps/web"

cd "$WEB_DIR"

if [ ! -d "android" ]; then
  echo "Android project missing. Run scripts/android_release_prepare.sh first."
  exit 1
fi

npm run build
npx cap sync android

cd android

if [ ! -f "keystore.properties" ]; then
  echo "Missing android/keystore.properties."
  echo "Copy keystore.properties.example and fill real values."
  exit 1
fi

./gradlew bundleRelease
./gradlew assembleRelease

echo ""
echo "AAB:"
find app/build/outputs/bundle/release -name "*.aab" -print || true
echo ""
echo "APK:"
find app/build/outputs/apk/release -name "*.apk" -print || true
