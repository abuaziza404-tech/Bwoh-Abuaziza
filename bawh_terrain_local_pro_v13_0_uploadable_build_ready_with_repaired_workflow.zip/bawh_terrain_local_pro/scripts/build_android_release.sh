#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR/apps/web"
npm install
npm run build
if [ ! -d android ]; then
  npx cap add android
fi
npx cap sync android
cd android
if [ ! -f keystore.properties ]; then
  echo "Missing apps/web/android/keystore.properties. See ANDROID_BUILD_GUIDE.md"
  exit 1
fi
./gradlew bundleRelease
./gradlew assembleRelease
find app/build/outputs -type f \( -name "*.aab" -o -name "*.apk" \) -print
