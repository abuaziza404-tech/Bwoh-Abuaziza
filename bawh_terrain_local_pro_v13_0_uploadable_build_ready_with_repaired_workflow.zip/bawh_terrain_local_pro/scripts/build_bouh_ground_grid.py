#!/usr/bin/env python3
from __future__ import annotations

"""
BOUH v12.5 Ground Grid Builder

Purpose:
- Build a compact ground grid from real imported rasters under data/imports.
- Never use PNG/JPG/KMZ/Browser Images to compute spectral indices.
- If rasters are missing, it exports only a "no_raw_grid" status and does not invent results.

Expected imports:
  data/imports/sentinel2/
  data/imports/landsat8_171046_20260516/
  data/imports/dem/
  data/precomputed/bouh_seed_cells_v12_5.json

Output:
  data/precomputed/bouh_ground_grid.sqlite
  data/precomputed/BOUH_GROUND_GRID_BUILD_REPORT.md
"""

import argparse
import json
import math
import os
import sqlite3
from pathlib import Path
from typing import Any

VISUAL_EXT = {".png", ".jpg", ".jpeg", ".kmz", ".kml"}
RASTER_EXT = {".tif", ".tiff"}

def is_visual(path: Path) -> bool:
    return path.suffix.lower() in VISUAL_EXT or "browser_images" in str(path).lower()

def classify(path: Path) -> str:
    n = path.name.lower()
    if is_visual(path):
        return "visual_context_only"
    if path.suffix.lower() not in RASTER_EXT:
        if path.suffix.lower() in {".json", ".csv", ".txt", ".md"}:
            return "registry_or_metadata"
        return "unknown"
    if "sentinel" in n or any(b in n for b in ["_b02", "_b03", "_b04", "_b08", "_b8a", "_b11", "_b12"]):
        return "sentinel_raw"
    if "lc08" in n or "landsat" in n or "qa_pixel" in n:
        return "landsat_raw"
    if "dem" in n or "srtm" in n or "n19_e036" in n:
        return "dem"
    return "raster_unknown"

def safe_ratio(a, b):
    return None if b is None or abs(b) < 1e-9 or a is None else (a / b)

def norm(value, lo, hi):
    if value is None:
        return None
    if hi == lo:
        return 0.0
    return max(0.0, min(1.0, (float(value) - lo) / (hi - lo)))

def classify_score(score: float | None, guards: list[str]) -> str:
    if score is None:
        return "Needs More Data"
    if "reject" in guards:
        return "Reject"
    if score >= 80:
        return "Class A - Field-check priority"
    if score >= 67:
        return "Class B"
    if score >= 55:
        return "Class C"
    if score >= 40:
        return "Needs More Data"
    return "Reject"

def create_empty_db(out_db: Path) -> None:
    out_db.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(out_db)
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS ground_cells (
      cell_id TEXT PRIMARY KEY,
      latitude REAL NOT NULL,
      longitude REAL NOT NULL,
      zone TEXT,
      ndvi REAL,
      ndwi REAL,
      bsi REAL,
      ndmi REAL,
      iron_b04_b02 REAL,
      swir_b11_b12 REAL,
      dry_b11_b08 REAL,
      slope REAL,
      hillshade REAL,
      terrain_score REAL,
      alteration_score REAL,
      structure_score REAL,
      dryness_score REAL,
      evidence_count INTEGER,
      final_ground_score REAL,
      class TEXT,
      source_layers TEXT,
      truth_status TEXT,
      limitation_ar TEXT,
      payload_json TEXT
    )
    """)
    cur.execute("CREATE INDEX IF NOT EXISTS idx_ground_lat_lng ON ground_cells(latitude, longitude)")
    conn.commit()
    conn.close()

def build_from_rasters(import_root: Path, out_db: Path, model_path: Path, seed_path: Path, cell_size_m: int = 30) -> dict[str, Any]:
    files = [p for p in import_root.rglob("*") if p.is_file()] if import_root.exists() else []
    classified = [{"path": str(p), "name": p.name, "class": classify(p)} for p in files]
    visual_used_for_compute = [x for x in classified if x["class"] == "visual_context_only"]

    raster_files = [x for x in classified if x["class"] in {"sentinel_raw", "landsat_raw", "dem"}]
    out_db.parent.mkdir(parents=True, exist_ok=True)

    if visual_used_for_compute:
        # This list is allowed to exist but never used for numeric computation.
        pass

    # Try real raster build only when rasterio/numpy are available and enough raw layers exist.
    try:
        import numpy as np  # type: ignore
        import rasterio  # type: ignore
        from rasterio.warp import transform  # type: ignore
    except Exception as exc:
        create_empty_db(out_db)
        return {
            "ok": False,
            "status": "no_raw_grid_built",
            "reason": f"rasterio/numpy unavailable: {exc}",
            "import_root": str(import_root),
            "raster_count": len(raster_files),
            "visual_files_ignored": len(visual_used_for_compute),
            "output_db": str(out_db),
            "truth_status": "no_raw_pixel_results",
        }

    if not raster_files:
        create_empty_db(out_db)
        return {
            "ok": False,
            "status": "no_raw_grid_built",
            "reason": "No calculation-grade rasters found under data/imports.",
            "import_root": str(import_root),
            "raster_count": 0,
            "visual_files_ignored": len(visual_used_for_compute),
            "output_db": str(out_db),
            "truth_status": "no_raw_pixel_results",
        }

    # Practical conservative builder:
    # 1. Use any single raster as reference grid.
    # 2. Sample a stride to keep mobile grid compact.
    # 3. If bands are not fully resolvable, record evidence_count and do not fabricate absent indices.
    reference_path = Path(raster_files[0]["path"])
    create_empty_db(out_db)
    conn = sqlite3.connect(out_db)
    cur = conn.cursor()

    max_cells = int(os.getenv("BOUH_MAX_GRID_CELLS", "25000"))
    rows_written = 0

    with rasterio.open(reference_path) as src:
        arr = src.read(1, masked=True)
        h, w = arr.shape
        stride = max(1, int(math.sqrt((h * w) / max_cells)))
        for row in range(0, h, stride):
            for col in range(0, w, stride):
                if rows_written >= max_cells:
                    break
                if arr.mask[row, col]:
                    continue
                x, y = src.xy(row, col)
                if src.crs and str(src.crs).upper() != "EPSG:4326":
                    lon, lat = transform(src.crs, "EPSG:4326", [x], [y])
                    lng, latv = lon[0], lat[0]
                else:
                    lng, latv = x, y

                # Conservative: no full index values unless all named bands are mapped.
                evidence_count = len(set(x["class"] for x in raster_files))
                score = None
                cls = "Needs More Data"
                truth_status = "raw_grid_cell_location_only"
                limitation = "تم بناء خلية مكانية من raster reference، لكن لم تكتمل خريطة الباندات لحساب المؤشرات. لا توجد نتيجة ذهب."

                payload = {
                    "reference_raster": str(reference_path.name),
                    "cell_size_m": cell_size_m,
                    "evidence_count": evidence_count,
                    "raw_classes_available": sorted(set(x["class"] for x in raster_files)),
                }
                cur.execute("""
                INSERT OR REPLACE INTO ground_cells (
                    cell_id, latitude, longitude, zone, evidence_count, final_ground_score, class,
                    source_layers, truth_status, limitation_ar, payload_json
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?)
                """, (
                    f"grid_{rows_written:07d}",
                    float(latv), float(lng), None, evidence_count, score, cls,
                    json.dumps(sorted(set(x["name"] for x in raster_files)), ensure_ascii=False),
                    truth_status, limitation, json.dumps(payload, ensure_ascii=False)
                ))
                rows_written += 1
            if rows_written >= max_cells:
                break

    conn.commit()
    conn.close()

    return {
        "ok": True,
        "status": "ground_grid_locations_built",
        "note": "Grid locations built conservatively. Full spectral scoring requires explicit band mapping.",
        "output_db": str(out_db),
        "rows_written": rows_written,
        "raster_count": len(raster_files),
        "visual_files_ignored": len(visual_used_for_compute),
        "truth_status": "partial_raw_grid_not_full_score",
    }

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--import-root", default="data/imports")
    parser.add_argument("--out-db", default="data/precomputed/bouh_ground_grid.sqlite")
    parser.add_argument("--model", default="configs/ground_score_model_v12_5.json")
    parser.add_argument("--seed", default="data/precomputed/bouh_seed_cells_v12_5.json")
    parser.add_argument("--cell-size-m", type=int, default=30)
    args = parser.parse_args()

    result = build_from_rasters(
        import_root=Path(args.import_root),
        out_db=Path(args.out_db),
        model_path=Path(args.model),
        seed_path=Path(args.seed),
        cell_size_m=args.cell_size_m,
    )

    report = Path("data/precomputed/BOUH_GROUND_GRID_BUILD_REPORT.md")
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(
        "# BOUH Ground Grid Build Report\n\n"
        f"```json\n{json.dumps(result, ensure_ascii=False, indent=2)}\n```\n\n"
        "## Truth Rule\n"
        "No Gold Proof. No depth. No 100% confidence. PNG/JPG/KMZ are visual-only.\n",
        encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
