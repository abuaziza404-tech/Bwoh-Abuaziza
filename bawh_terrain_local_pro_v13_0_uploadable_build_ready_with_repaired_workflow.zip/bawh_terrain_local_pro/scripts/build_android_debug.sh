#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR/apps/web"
npm install
npm run build
if [ ! -d android ]; then
  npx cap add android
fi
npx cap sync android
cd android
./gradlew assembleDebug
find app/build/outputs/apk/debug -name "*.apk" -print
