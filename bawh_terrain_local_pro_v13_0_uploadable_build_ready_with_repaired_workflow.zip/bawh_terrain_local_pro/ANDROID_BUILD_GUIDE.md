# Android Build Guide — بوح التضاريس

Package ID: `com.bawh.terrain`

## Debug APK

```bash
cd apps/web
npm install
npm run android:init
npm run android:apk:debug
```

أو من الجذر:

```bash
bash scripts/build_android_debug.sh
```

## Release AAB/APK

1. جهّز keystore خارج Git:

```bash
keytool -genkeypair -v \
  -keystore bawhterrain-release.keystore \
  -alias bawhterrain \
  -keyalg RSA \
  -keysize 4096 \
  -validity 10000
```

2. أنشئ `apps/web/android/keystore.properties` بعد إنشاء مشروع Android:

```properties
storeFile=/absolute/path/bawhterrain-release.keystore
storePassword=YOUR_STORE_PASSWORD
keyAlias=bawhterrain
keyPassword=YOUR_KEY_PASSWORD
```

3. ابنِ:

```bash
bash scripts/build_android_release.sh
```

## ملاحظات

- يجب توفر Android SDK وJDK وGradle.
- لا تضع keystore أو كلمات المرور داخل Git.
- إذا لم يوجد مجلد `apps/web/android` سيتم إنشاؤه عبر Capacitor.
