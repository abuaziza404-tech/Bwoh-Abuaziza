# الدليل الميداني — بوح التضاريس | منظومة أبوعزيزة

المطور المعتمد: أحمد أبوعزيزة الرشيدي

## القاعدة العلمية

بوح التضاريس منصة تحليل تضاريس وطبقات سطحية وسلامة ميدانية. النتائج احتمالية وتحتاج تحقق ميداني. النظام لا يثبت وجود ذهب أو دفائن أو أهداف تحت الأرض.

## ترتيب العمل

1. افتح التطبيق وتأكد من حالة Online/Offline.
2. أنشئ مشروعًا وحدد الموقع أو استخدم GPS الجهاز.
3. احفظ منطقة الخرائط إذا كنت ستعمل دون إنترنت.
4. ارفع GeoTIFF/DEM/Bands عند توفرها.
5. استخدم الرادار لتوليد طبقات: Hillshade, Slope, Flow, NDVI, NDWI, BSI, NDMI.
6. افتح المكتبة لمقارنة South/Center/North.
7. افتح السلامة قبل النزول الميداني.
8. أنشئ تقريرًا عربيًا.
9. لا تعتمد على صورة بصرية وحدها كدليل رقمي.

## GPZ Strategy

- إذا Magnetic Ground Risk > 0.75:
  - Ground Type: Severe/Difficult
  - Gold Mode: High Yield
  - Sensitivity: 8–11
  - Audio Smoothing: Low/On
  - Swing: Slow

- إذا Magnetic Ground Risk < 0.45 وQuartz_QI مرتفع:
  - Ground Type: Normal
  - Gold Mode: General/Deep
  - Sensitivity: 12–16
  - Audio Smoothing: Off
  - Swing: Slow controlled

- إذا البيانات غير كافية:
  - إعداد GPZ تقديري يحتاج فحص أرضي.
