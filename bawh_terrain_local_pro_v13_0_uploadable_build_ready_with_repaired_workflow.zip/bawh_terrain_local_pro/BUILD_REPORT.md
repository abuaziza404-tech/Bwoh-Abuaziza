# BUILD_REPORT.md — v12.6 Final Ready Analyzed Ground Grid

## Release basis

This build adopts v12.6 as:

```text
Final Ready Analyzed Ground Grid
```

The Android release candidate v12.7 does not change the v12.6 analytical database, weights, or field names.

# v12.6 Final Ready Analyzed Ground Grid

## Source package

Integrated the real package:

```text
BOUH_v12_6_READY_ANALYZED_GROUND_GRID_DATA.zip
SHA256=c89cedffb3916878f4fee9a22868300af43fc85874d9d79ef69ee657816c949d
```

## SQLite integration

Copied:

```text
data/precomputed/bouh_ground_grid.sqlite
```

Verified:

```text
sqlite3 data/precomputed/bouh_ground_grid.sqlite "select count(*) from ground_cells;"
4303
```

## Analysis status

```text
ground_cells = 4303
analysis_type = partial ready analyzed ground grid
sources = Landsat reflectance composite, Landsat TIR, Landsat QA_PIXEL, DEM n19_e036_3arc_v2
```

This is a partial ready analyzed grid according to available Landsat/DEM cells. It is not a true Sentinel/SWIR full spectral stack.

Not calculated yet:

```text
true Sentinel NDVI
true Sentinel NDWI
true Sentinel BSI
true Sentinel NDMI
true SWIR full-stack indices
```

## Live score API verification

`/bouh/live-score/status` returned:

```json
{
  "ground_grid_exists": true,
  "ground_grid_cell_count": 4303
}
```

T1 exact point test:

```text
curl "http://localhost:8000/bouh/live-score?lat=19.9732&lng=36.7456&radius=300"
mode = seed_context_only
```

Reason: no ground grid cell exists within 300m of the exact T1 seed point, so the API correctly falls back to the official seed context without inventing a result.

Nearest actual analyzed ground-grid cell test:

```text
lat=19.976844531578084
lng=36.741732589512296
radius=300
mode = ground_grid
final_ground_score = 66.0
class = Class C
```

## Tests

```text
python scripts/validate_v12_5_analytical_pack.py
rc=0

pytest tests/test_v12_6_ready_analyzed_grid.py -q
rc=0
result=1 passed

pytest tests/test_live_score_repository.py -q
rc=0
result=3 passed
```

## Scientific restrictions

- No Gold Proof
- No Depth
- No 100%
- No Gold Target wording
- Ground score only
- Surface screening only
- Field-check only
- Partial analyzed grid only
- No NDVI/BSI/NDMI from PNG/JPG/KMZ
- No claim that analysis is every meter real

## Android assets

No GeoTIFF/TIFF/DEM/ZIP/JP2/MBTiles/PMTiles were added to Android assets.

# v12.7 Android Release Candidate

## Scope

Only Android release-candidate packaging and verification.

No changes were made to:

```text
data/precomputed/bouh_ground_grid.sqlite
ground_cells = 4303
analysis fields
score weights
field names
```

Scientific wording remains:

```text
partial ready analyzed ground grid from Landsat/DEM
No Gold Proof
No Depth
No 100%
No Gold Target
```

# v12.7 Android Release Candidate Execution

## Ground grid integrity

```text
ground_cells = 4303
database_changed = false
weights_changed = false
field_names_changed = false
```

## Top analyzed cells live-score test

Checked top 20 cells ordered by `final_ground_score desc`.

```text
top20_checked = 20
all_top20_mode = ground_grid
top_cell_lat = 19.41022162800518
top_cell_lng = 36.86820999932388
top_cell_score = 66.0
top_cell_class = Class C
truth_status = partial_raw_grid_landsat_dem_not_full_spectral
```

## API verification

Started FastAPI with:

```bash
BOUH_PRECOMPUTED_DIR=data/precomputed
BOUH_SKIP_DB_STARTUP=1
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

`BOUH_SKIP_DB_STARTUP=1` was used because the local sqlite test environment does not provide Spatialite `RecoverGeometryColumn`. Docker/PostGIS production startup remains the intended full DB environment.

Verified:

```text
GET /bouh/live-score/status
ground_grid_exists = true
ground_grid_cell_count = 4303

GET /bouh/live-score?lat=19.41022162800518&lng=36.86820999932388&radius=300
mode = ground_grid
```

## Docker verification

Attempted:

```bash
docker compose config
docker compose build
```

Result:

```text
docker_compose_config rc=-1
docker_compose_build rc=-1
```

Environment blocker:

```text
[Errno 13] Permission denied: 'docker'
```

## Android build attempt

Commands attempted:

```bash
cd apps/web/android
./gradlew assembleDebug
./gradlew bundleRelease
```

Results:

```text
assembleDebug rc=1
bundleRelease rc=1
apk_aab_outputs = 0
```

Failure reason:

```text
java.net.UnknownHostException: services.gradle.org
```

No APK/AAB was generated in this environment due to Gradle distribution download failure.

## Scientific wording

Use only:

```text
partial ready analyzed ground grid from Landsat/DEM
Ground score
Surface screening
Field-check
```

Do not use:

```text
Gold Proof
Depth
100%
Gold Target
Sentinel/SWIR complete
```

# v12.8 Final Android Artifacts

## Scope

This release only regenerates checksums and attempts Android build artifacts. It does not change:

```text
bouh_ground_grid.sqlite
ground_cells = 4303
score weights
field names
truth_status
scientific guardrails
```

## Analytical baseline

```text
partial ready analyzed ground grid from Landsat/DEM
No Gold Proof
No Depth
No 100%
No Gold Target
Surface screening only
```

## Database verification

```text
ground_cells = 4303
top_cell_id = partial_raw_0004117
top_cell_lat = 19.41022162800518
top_cell_lng = 36.86820999932388
top_cell_score = 66.0
top_cell_class = Class C
truth_status = partial_raw_grid_landsat_dem_not_full_spectral
```

## Android build attempt

Commands executed:

```bash
cd apps/web/android
./gradlew assembleDebug
./gradlew bundleRelease
```

Result:

```text
assembleDebug rc=1
bundleRelease rc=1
apk_aab_outputs = 0
```

If no APK/AAB exists, the blocker is:

```text
java.net.UnknownHostException: services.gradle.org
```

## Checksums

`CHECKSUMS_ANDROID.txt` was regenerated first. `CHECKSUMS_FULL.txt` was then regenerated last in standard format:

```text
SHA256  relative/path
```

## Android assets policy

No GeoTIFF/TIFF/DEM/ZIP/JP2/MBTiles/PMTiles were added to Android assets.

# v12.9 Installable Android Release Attempt

## Analytical baseline

v12.8 is adopted as the Final Android Artifacts Source Package.

No changes were made to:

```text
bouh_ground_grid.sqlite
ground_cells = 4303
score weights
field names
truth_status
scientific guardrails
```

## Build target

Requested output:

```text
APK Debug
AAB Release
```

## Android build execution

Commands executed:

```bash
cd apps/web/android
./gradlew assembleDebug
./gradlew bundleRelease
```

Results:

```text
assembleDebug rc=1
bundleRelease rc=1
apk_aab_outputs = 0
```

Current environment blocker:

```text
java.net.UnknownHostException: services.gradle.org
```

No APK/AAB was generated in this environment because Gradle could not download:

```text
https://services.gradle.org/distributions/gradle-8.14.3-all.zip
```

## CHECKSUMS_ANDROID

`CHECKSUMS_ANDROID.txt` was updated after the build attempt. Since APK/AAB were not produced, it documents the Gradle network blocker instead of artifact hashes.

## Ground grid report cleanup

`data/precomputed/BOUH_GROUND_GRID_BUILD_REPORT.md` now starts with:

```text
ground_cells = 4303
partial ready analyzed ground grid from Landsat/DEM
```

## Android assets policy

No GeoTIFF/TIFF/DEM/ZIP/JP2/MBTiles/PMTiles were added to Android assets.

## Scientific wording

```text
partial ready analyzed ground grid from Landsat/DEM
No Gold Proof
No Depth
No 100%
No Gold Target
Surface screening only
```

# v13.0 GitHub Actions Build Ready Package

## Naming decision

The requested installable package name is only valid if an actual `.apk` or `.aab` exists inside the ZIP.

Build result in this environment:

```text
apk_aab_outputs = 0
```

Therefore this build is named:

```text
bawh_terrain_local_pro_v13_0_github_actions_build_ready_package.zip
```

and not named `bawh_terrain_local_pro_v13_0_installable_apk_aab_release.zip`.

## Android build attempt

Commands executed:

```bash
cd apps/web/android
./gradlew assembleDebug
./gradlew bundleRelease
```

Results:

```text
assembleDebug rc=1
bundleRelease rc=1
```

Failure reason:

```text
java.net.UnknownHostException: services.gradle.org
```

Gradle could not download:

```text
https://services.gradle.org/distributions/gradle-8.14.3-all.zip
```

## Analytical integrity

No changes were made to:

```text
bouh_ground_grid.sqlite
ground_cells = 4303
score weights
field names
truth_status
No Gold Proof / No Depth / No 100% policy
```

## Verified data

```text
ground_cells = 4303
truth_status = partial_raw_grid_landsat_dem_not_full_spectral
top_cell_id = partial_raw_0004117
top_cell_score = 66.0
top_cell_class = Class C
```

## Scientific wording

```text
partial ready analyzed ground grid from Landsat/DEM
No Gold Proof
No Depth
No 100%
No Gold Target
Surface screening only
```

## Android assets policy

No GeoTIFF/TIFF/DEM/ZIP/JP2/MBTiles/PMTiles were added to Android assets.

## To produce the installable release

Run the existing `android-build` GitHub Actions job or execute on Android Studio / connected build machine:

```bash
cd apps/web
npm install
npm run build
npx cap sync android
cd android
./gradlew assembleDebug
./gradlew bundleRelease
sha256sum app/build/outputs/apk/debug/*.apk
sha256sum app/build/outputs/bundle/release/*.aab
```

Then update `CHECKSUMS_ANDROID.txt` with real APK/AAB hashes and package as:

```text
bawh_terrain_local_pro_v13_0_installable_apk_aab_release.zip
```

# GitHub Actions ZIP Android Builder

Added workflow:

```text
.github/workflows/android-build-from-zip.yml
```

Purpose:

```text
Build APK Debug and AAB Release from one ZIP placed at repository root:
bawh_terrain_local_pro_v13_0_github_actions_build_ready_package.zip
```

The workflow verifies before building:

```text
data/precomputed/bouh_ground_grid.sqlite exists
ground_cells = 4303
truth_status = partial_raw_grid_landsat_dem_not_full_spectral
no GeoTIFF/TIFF/DEM/ZIP/JP2/MBTiles/PMTiles in Android assets
```

The workflow produces and uploads:

```text
APK Debug
AAB Release
CHECKSUMS_ANDROID.txt
BOUH_v13_0_INSTALLABLE_ANDROID_ARTIFACTS.zip
```

Analytical restrictions remain unchanged:

```text
No Gold Proof
No Depth
No 100%
No Gold Target
Surface screening only
partial ready analyzed ground grid from Landsat/DEM
```
