# BOUH v12.6 Raw Imports Ground Grid Build Report

تم تنزيل ملفات حسابية فعلية من Google Drive وبناء Ground Grid جزئي.

- bouh_ground_grid.sqlite: موجود
- عدد خلايا ground_cells: 4303
- أعلى درجة: 66.0
- متوسط الدرجة: 57.23722379735069

## مصادر البيانات المستخدمة

- Landsat reflectance composite: LC08...refl_wgs84_px.tiff
- Landsat TIR: LC08...tir_wgs84_px.tiff
- Landsat QA: LC08...QA_PIXEL_wgs84_u.tiff
- DEM: n19_e036_3arc_v2.tif

## حدود الصدق

هذه ليست شبكة Sentinel/SWIR كاملة. لا توجد داخل هذه الحزمة باندات Sentinel B02/B03/B04/B08/B8A/B11/B12.

لذلك NDVI/NDWI/BSI/SWIR الحقيقي غير محسوب.

تم حساب مؤشرات جزئية فقط: brightness proxy, red/green proxy, TIR brightness, DEM elevation, DEM slope proxy.

النتيجة capped at Class C. No Gold Proof. No depth. No 100%.
