# سياسة الأمان — بوح التضاريس

المطور: **أحمد أبوعزيزة الرشيدي**

## مبادئ الأمان

- Offline-first.
- لا يتم تنفيذ أي ملف مرفوع.
- ZIP extraction آمن ضد path traversal.
- حد حجم للرفع.
- فحص الامتداد و MIME.
- Audit log قابل للتوسعة.
- Cache محلي للبيانات الخارجية.
- فشل آمن عند انقطاع الإنترنت.
- فصل ميزات Offline عن Online.
- النظام لا يدعي كشف ما تحت الأرض.

## طبقات الحماية المقترحة للنشر

- HTTPS.
- توقيع الإصدارات.
- Content Security Policy.
- Rate limiting.
- Auth/RBAC.
- تشفير النسخ الاحتياطية.
- تدوير مفاتيح API.


## Android Field Mode

- يفضل تفعيل التخزين الدائم من داخل التطبيق.
- لا تُرفع ملفات مجهولة المصدر إلا بعد فحصها.
- استخدم HTTPS عند نشر API خارج الشبكة المحلية.
- APK النهائي يجب توقيعه بمفتاح خاص آمن.
- لا تشارك keystore أو مفاتيح API داخل المستودع.


## PIN/Biometrics

- PIN محلي على الجهاز ولا يرسل للخادم.
- WebAuthn/Biometrics يستخدم Credential محلي.
- هذا القفل يحمي واجهة التطبيق على الجهاز، ولا يغني عن تشفير نظام التشغيل أو صلاحيات API عند النشر.


## JWT/RBAC

- غيّر `APP_SECRET_KEY` قبل production.
- أنشئ مديرًا واحدًا عبر `/auth/bootstrap-admin`.
- استخدم HTTPS عند فتح API خارج الشبكة المحلية.
- لا تحفظ رموز Bearer في أماكن عامة.
- PIN المحلي لا يغني عن حماية API.


## v12 Upload Hardening

- فحص الامتداد والحجم.
- منع الامتدادات الخطرة.
- KML/KMZ/PNG/JPG سياق بصري فقط.
- لا يتم تنفيذ أي ملف مرفوع.
- ZIP يجب أن يحظر path traversal عبر safe extractor.
- API keys عبر `.env` فقط.
- Android keystore خارج Git.
- JWT roles: admin, analyst, field_user, viewer.
- إن لم يكتمل ربط JWT على كل endpoints فهو security scaffold محلي وليس production auth كامل.
