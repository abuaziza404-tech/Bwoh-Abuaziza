# Release Signing Checklist

- [ ] تغيير `APP_SECRET_KEY` في `.env`.
- [ ] إنشاء admin من `/auth/bootstrap-admin`.
- [ ] اختبار `/auth/login`.
- [ ] تشغيل `scripts/test_docker_full.sh`.
- [ ] بناء PWA.
- [ ] تشغيل Android Studio.
- [ ] إنشاء keystore خارج المشروع.
- [ ] بناء APK/AAB release.
- [ ] تجربة التثبيت على هاتف Android.
- [ ] حفظ منطقة Offline من Esri Satellite.
- [ ] تجربة العمل بدون إنترنت.
- [ ] عدم مشاركة keystore أو كلمات المرور.
