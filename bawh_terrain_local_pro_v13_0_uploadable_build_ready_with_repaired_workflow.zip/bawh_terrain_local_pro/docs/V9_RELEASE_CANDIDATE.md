# بوح التضاريس Local Pro v9 — Release Candidate

المطور: أحمد أبوعزيزة الرشيدي

## W — مدير تنزيل خرائط Offline

تمت إضافة مدير تنزيل خرائط Offline داخل الرادار:

- إنشاء خطة تنزيل حول مركز الرادار.
- تحديد Min/Max Zoom.
- حساب عدد Tiles قبل التنزيل.
- تنزيل Esri Satellite + Esri Reference + OSM Streets إلى Cache المتصفح.
- حفظ حالة الخطة داخل API:
  - planned
  - completed
  - completed_with_errors

Endpoints:
- `POST /offline-map-downloads`
- `GET /offline-map-downloads`
- `GET /offline-map-downloads/{id}/plan`
- `POST /offline-map-downloads/{id}/mark-complete`

## D — CI واختبارات

تمت إضافة GitHub Actions:

- API tests
- Web tests
- Web build
- Docker compose config

ملف:
- `.github/workflows/ci.yml`

اختبارات جديدة:
- `test_tile_planner.py`
- `native.test.ts`

## E — Capacitor Native GPS/Storage

تمت إضافة تجهيزات Native:

- `@capacitor/geolocation`
- `@capacitor/preferences`
- `@capacitor/filesystem`
- ملف `src/native.ts`
- زر GPS الجهاز داخل الرادار
- سكربت:
  - `npm run android:sync:native`

## Z — Release Candidate

هذه النسخة Release Candidate منظمة للتجربة النهائية قبل APK/AAB release.

## أوامر Android

```bash
cd apps/web
npm install
npm run android:sync:native
npm run android:apk:debug
```

## ملاحظات

- Native GPS يعمل داخل Capacitor، ويستخدم Web Geolocation داخل المتصفح.
- تنزيل الخرائط يعتمد على Cache المتصفح/Android WebView.
- للمناطق الضخمة جدًا استخدم MBTiles/PMTiles.
