# بوح التضاريس Local Pro v7 — MBTiles / PMTiles / Android Security

المطور: أحمد أبوعزيزة الرشيدي

## إضافات W

### MBTiles / PMTiles

- رفع MBTiles من الرادار.
- رفع PMTiles وحفظها كحزمة خام مستقبلية.
- فحص Metadata وZoom وBounds للحزمة.
- عرض MBTiles كطبقة Raster محلية داخل MapLibre.
- endpoint:
  - `POST /offline-map-packs`
  - `GET /offline-map-packs`
  - `GET /offline-map-packs/{id}/tiles/{z}/{x}/{y}.png`

## إضافات E

### قفل محلي PIN/Biometrics

- شاشة قفل محلية.
- PIN مخزن كـ SHA-256 في localStorage.
- دعم WebAuthn/Biometrics عند توفر المتصفح والجهاز.
- زر قفل سريع داخل التطبيق.
- لا يتم إرسال PIN إلى API.

## إضافات D

### اختبارات

Backend:
- اختبار قراءة MBTiles.
- اختبار تحويل TMS/XYZ.
- اختبار فحص metadata.

Frontend:
- Vitest.
- اختبار Tile math الخاص بحفظ الخرائط.

## التشغيل

```bash
docker compose up --build
```

## بناء Android

```bash
cd apps/web
npm install
npm run android:init
npm run android:apk:debug
```

## ملاحظة PMTiles

PMTiles محفوظ كملف خام داخل النظام. العرض المباشر يتطلب إضافة بروتوكول PMTiles في الواجهة أو تحويله إلى MBTiles. أما MBTiles فهو مدعوم للعرض المباشر الآن.
