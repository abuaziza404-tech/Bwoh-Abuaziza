# بوح التضاريس Local Pro v10 Final Release

المطور: أحمد أبوعزيزة الرشيدي

## حالة النسخة

هذه نسخة Final Release من المنظومة بعد دمج:

- رادار MapLibre.
- Esri Satellite / Hybrid / Streets.
- حفظ مناطق Offline.
- MBTiles مباشر.
- PMTiles مباشر.
- Android PWA.
- Capacitor Android.
- Native GPS/Preferences/Filesystem.
- PIN/Biometrics محلي.
- JWT/RBAC API.
- مدير تنزيل خرائط Offline.
- GitHub Actions CI.
- Android Release AAB/APK signing structure.

## تشغيل محلي

```bash
cp .env.example .env
docker compose up --build
```

## تشغيل Production

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml up --build -d
```

## Android PWA

من هاتف Android على نفس الشبكة:

```text
http://YOUR-LAN-IP:5173
```

ثم من Chrome:

```text
⋮ > Install app
```

## Android APK/AAB Debug

```bash
cd apps/web
npm install
npm run android:sync:native
npm run android:apk:debug
```

## Android Release AAB/APK

من جذر المشروع:

```bash
bash scripts/android_release_prepare.sh
```

أنشئ Keystore:

```bash
keytool -genkeypair -v \
  -keystore bawhterrain-release.keystore \
  -alias bawhterrain \
  -keyalg RSA \
  -keysize 4096 \
  -validity 10000
```

ثم انسخ:

```bash
cp apps/web/android/keystore.properties.example apps/web/android/keystore.properties
```

عدّل كلمات المرور والمسار الحقيقي.

ثم:

```bash
bash scripts/android_release_build_aab.sh
```

## مخرجات Release المتوقعة

```text
apps/web/android/app/build/outputs/bundle/release/app-release.aab
apps/web/android/app/build/outputs/apk/release/app-release.apk
```

## فحوصات قبل النشر

```bash
bash scripts/test_docker_full.sh
cd apps/web && npm run final:check
```

## الأمان

- غيّر `APP_SECRET_KEY`.
- لا ترفع keystore إلى Git.
- لا تحفظ كلمات مرور keystore داخل المشروع.
- استخدم HTTPS عند فتح API خارج الشبكة المحلية.
- PIN محلي للجهاز فقط.
- JWT/RBAC لحماية API.
- لا يتم تنفيذ أي ملف مرفوع.
- ZIP يفك بأمان.
- النظام لا يدعي كشف ما تحت الأرض.
